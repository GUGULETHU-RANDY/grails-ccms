package za.co.quirk.distell.ccms

class CcmsTagLib {

    static namespace = "ccms"

    def ageChecker = {attr, body ->
        def countryLabel = attr['countryLabel'] ?: 'Country:'
        def dobLabel = attr['dobLabel'] ?: 'Date of birth:'
        def dobSpacer = attr['dobSpacer'] ?: ''
        def requiredFieldsLabel = attr['requiredFieldsLabel'] ?: '*Required fields'
        def rememberMeLabel = attr['rememberMeLabel'] ?: 'Remember me'
        def submitLabel = attr['submitLabel'] ?: 'Submit'
        def useSelects = "true".equals(attr['useSelects']) ? true : false

        out << g.render(template: '/ageChecker/form',
                model: [
                        countryLabel: countryLabel,
                        dobLabel: dobLabel,
                        dobSpacer: dobSpacer,
                        requiredFieldsLabel:requiredFieldsLabel,
                        rememberMeLabel: rememberMeLabel,
                        submitLabel: submitLabel,
                        useSelects: useSelects],
                plugin: "grails-ccms")
    }

    def form = { attr, body ->
        def appName = attr['appName']
        def source = grailsApplication.config?.ccms?."$appName"?.source ?: appName
        if (grailsApplication.config?.ccms?."$appName"?.timestampSource) {source += "-${new Date().format('yyyy-MM-dd')}"}

        def country = grailsApplication.config?.ccms?."$appName"?.country ?: 'za'
        def errorMessages = getErrorMessages(appName)
        def emptySelectOption = grailsApplication.config?.ccms?."$appName"?.emptySelectOption ?: 'Please select'
        def useTextInputsForDob = grailsApplication.config?.ccms?."$appName"?.useTextInputsForDob
        def dobSpacer = grailsApplication.config?.ccms?."$appName"?.dobSpacer ?: ''
        def whatAboutOptions = grailsApplication.config?.ccms?."$appName"?.whatAboutOptions ?: ['Products','Events','General']
        def offlineAccess = attr['offlineAccess'] == "true"
        def contactMessageAreaRows = attr['contactMessageAreaRows'] ?: '5'
        def contactMessageAreaCols = attr['contactMessageAreaCols'] ?: '40'

        def labels = grailsApplication.config?.ccms?."$appName"?.labels ?: [
                first_name: 'First name*:',
                last_name: 'Surname*:',
                email: 'Email Address*:',
                mobile: 'Mobile Number*:',
                region: 'Province*:',
                dob: 'Date of Birth*:',
        ]

        def placeholders = grailsApplication.config?.ccms?."$appName"?.placeholders

        out << g.render(template: "/consumer/form",
                model: [
                        appName: appName,
                        labels: labels,
                        placeholders: placeholders,
                        errorMessages: errorMessages,
                        emptySelectOption: emptySelectOption,
                        useTextInputsForDob: useTextInputsForDob,
                        dobSpacer: dobSpacer,
                        whatAboutOptions: whatAboutOptions,
                        source: source,
                        country: country,
                        offlineAccess: offlineAccess,
                        contactMessageAreaRows: contactMessageAreaRows,
                        contactMessageAreaCols: contactMessageAreaCols],
                plugin: "grails-ccms")
        out << ccms.formScript([
                appName: appName,
                thankYouWrapperId: attr['thankYouWrapperId'],
                doneButtonId: attr['doneButtonId'],
                historyUris: attr['historyUris'],
                appName: appName,
                errorMessages: errorMessages,
                offlineAccess: offlineAccess])
    }

    def formScript = { attr, body ->
        def appName = attr['appName']
        def thankYouWrapper = attr['thankYouWrapperId'] ?: 'thankYouWrapper'
        def doneButtonId = attr['doneButtonId'] ?: 'doneButton'

        out << g.render(template: "/consumer/script",
                model: [
                        errorMessages: attr['errorMessages'],
                        thankYouWrapper: thankYouWrapper,
                        doneButtonId: doneButtonId,
                        appName: appName,
                        offlineAccess: attr['offlineAccess'],
                        historyUris: attr['historyUris']],
                plugin: "grails-ccms")
    }

    def offlineAccess = { attr, body ->
        out << """manifest="/consumer/manifest/${attr['appName']}" """
    }

    private Map getErrorMessages(String appName) {
        Map errorMessages

        if (grailsApplication.config.ccms."$appName".errorMessages) {
            errorMessages = grailsApplication.config.ccms."$appName".errorMessages
            if (errorMessages.net_promoter_score) {//add appName to
                errorMessages["brandFields.net_promoter_score_${appName}"] = errorMessages.net_promoter_score
                errorMessages.remove('net_promoter_score')
            }
        } else {
            errorMessages = [
                    first_name: 'Please enter your name',
                    last_name: 'Please enter your surname',
                    email: 'Please enter your email address',
                    mobile: 'Please enter your mobile number',
                    region: 'Please select your region',
                    dob: 'Please enter your date of birth',
                    dobUnderAge: 'You must be 18 or older to receive our news'
            ]
        }

        return errorMessages
    }
}
