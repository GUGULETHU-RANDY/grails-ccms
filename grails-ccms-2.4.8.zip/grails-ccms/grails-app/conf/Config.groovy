grails.project.groupId = "za.co.quirk.distell.ccms"
grails.app.context = "/"

ccms.consumerKey = 'Flight of the Fish Eagle'
ccms.consumerSecret = 'FOFE'
ccms.useLiveOnStaging = true
ccms.siteIdentifier = "test"
ccms.useAgeChecker = true

ccms.test = [
        source             : "Testing",
        labels             : [
                email     : 'Email: ',
                first_name: 'First Name: ',
                region    : "Region: ",
                dob       : 'Date of birth: ',
        ],
        placeholders       : [
                email                       : 'Email: ',
                first_name                  : 'First Name: ',
                last_name                   : 'Last Name: ',
                title                       : 'Title',
                dob                         : 'Date of birth: ',
                what_about                  : "What's this about?",
                region                      : "Region: ",
                mobile                      : 'Mobile: ',
                'brandFields.contactMessage': 'Message'
        ],
        whatAboutOptions   : ['One', 'Two'],
        useTextInputsForDob: true,
        dobSpacer          : '-',
        errorMessages      : [
                email     : 'Email',
                first_name: 'First Name',
                title     : 'Title please',
                region    : 'Please enter a region',
                dob       : 'Date of birth',
                gender    : 'Please enter a gender',
                mobile    : 'Enter a mobile number'
        ],
        manifest           : [
                '#v1',
                'index',
                '/consumer/js/jquery-1.8.min.js'
        ],
        timestampSource    : true,
        beforeSend         : { params, request ->
            println 'Before send'
            println params
            println request.class
        }
]

facebook {
    app {
        id = 504617329570969
        secret = 'xxxxxxx'
        scope = "email"
        redirectUri = "http://localhost:8080/facebook/auth"
    }
}

grails.mail.default.from = "test.quirk69@gmail.com"
grails {
    mail {
        host = "smtp.gmail.com"
        port = 465
        username = "test.quirk69@gmail.com"
        password = "xxx"
        props = ["mail.smtp.auth"                  : "true",
                 "mail.smtp.socketFactory.port"    : "465",
                 "mail.smtp.socketFactory.class"   : "javax.net.ssl.SSLSocketFactory",
                 "mail.smtp.socketFactory.fallback": "false"]
    }
}

log4j = {
    error 'org.codehaus.groovy.grails.web.servlet',
            'org.codehaus.groovy.grails.web.pages',
            'org.codehaus.groovy.grails.web.sitemesh',
            'org.codehaus.groovy.grails.web.mapping.filter',
            'org.codehaus.groovy.grails.web.mapping',
            'org.codehaus.groovy.grails.commons',
            'org.codehaus.groovy.grails.plugins',
            'org.codehaus.groovy.grails.orm.hibernate',
            'org.springframework',
            'org.hibernate',
            'net.sf.ehcache.hibernate'

    warn 'org.mortbay.log'
}

grails.plugin.geoip.data.resource = '/data/maxmind/GeoLiteCity.dat'
