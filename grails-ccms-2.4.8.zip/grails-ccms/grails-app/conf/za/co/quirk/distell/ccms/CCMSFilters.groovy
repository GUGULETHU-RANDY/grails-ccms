package za.co.quirk.distell.ccms

import za.co.quirk.distel.ccms.RobotSpotter
import za.co.quirk.distel.ccms.Utilities

class CCMSFilters {

    def grailsApplication

    def filters = {
        String controllerExclude = grailsApplication.config.ccms?.ageCheckerExclude ?: 'ageChecker|assets|errors|facebook'

        ageChecker(controllerExclude: controllerExclude) {
            before = {
                if (grailsApplication.config.ccms.useAgeChecker) {
                    if (RobotSpotter.isRobotUserAgent(request.getHeader('User-Agent'))) {

                        return true
                    }

                    def redirectUri = request.forwardURI

                    if (!session.ageCheckerDob && !session.ageCheckerBoolean) {
                        session.ageCheckerRedirectUri = request.forwardURI + ((request.queryString && request.queryString.size() > 0) ? ('?' + request.queryString) : '')

                        def ageCheckerUri = grailsApplication.config.ccms.ageCheckerUri

                        if (request.queryString && request.queryString.size() > 0) {
                            def newQueryString = "?${request.queryString}";

                            ageCheckerUri += newQueryString
                        }
                        redirect(uri: (ageCheckerUri ?: '/agechecker'))

                        return false
                    }
                }

                return true
            }
            after = { Map model -> }
            afterView = { Exception e -> }
        }
    }
}
