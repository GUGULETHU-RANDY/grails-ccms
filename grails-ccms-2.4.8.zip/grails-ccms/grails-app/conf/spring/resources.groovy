import za.co.quirk.distel.ccms.grailsservice.AgeCheckerService
import za.co.quirk.distel.ccms.grailsservice.FacebookService

beans = {
    if (application.config?.ccms?.consumerKey instanceof String &&
            application.config?.ccms?.consumerSecret instanceof String ) {

        ageCheckerService(AgeCheckerService) {
            grailsApplication = ref('grailsApplication')
        }

        facebookService(FacebookService) {
            grailsApplication = ref('grailsApplication')
        }
    }
}