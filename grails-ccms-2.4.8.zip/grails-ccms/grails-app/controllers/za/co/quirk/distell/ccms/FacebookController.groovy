package za.co.quirk.distell.ccms

import za.co.quirk.distel.ccms.CountryUtilities

class FacebookController {
    def facebookService
    def ageCheckerService
    def grailsApplication

    def auth() {
        def logging = false
        if(grailsApplication.config.ccms.facebookDebugging == true){
            logging = true
        }

        Boolean success = false
        if(logging){
            log.info("Start of Facebook auth")
        }

        if (params.code) {
            try {
                Map loginResponse = facebookService.loadAccessTokenFromFb(params.code)
                if(logging){
                    log.info("loginResponse: " +  loginResponse)
                }

                if (facebookService.login(session, loginResponse)) {
                    if(logging){
                        log.info("facebookService.login(session, loginResponse) == true")
                    }
                    session.fbUser = facebookService.loadUserFromFb(session, grailsApplication.config.facebook.app.fields ?: null)

                    if(logging){
                        log.info("session.fbUser: " + session.fbUser)
                    }

                    Integer age = facebookService.loadUserAgeRange(session).age_range.min
                    if(logging){
                        log.info("age: " + age)
                    }
                    success = ageCheckerService.isLegit(age, 'ZA')

                    if(logging){
                        log.info("success = ageCheckerService.isLegit(age, 'ZA'): " + success)
                    }
                } else {
                    if(logging){
                        log.info("facebookLoginService.login :: failed")
                    }
                }
            }
            catch (Exception e) {
                log.error("Exception retrieving user age from Facebook" + e)
            }
        }

        session.ageCheckerBoolean = success

        if(grailsApplication.config.ccms.getFacebookCountry){
            def fbCountry = CountryUtilities.getFacebookUserLocation(session.fbUser?.location)
            if(fbCountry){
                session.localeIdentifier = fbCountry
            } else {
                session.localeIdentifier = grailsApplication.config.ccms.facebookCountryDefault ?: "ZA"
            }

            if(logging){
                log.info("getFacebookCountry set to: " + session.localeIdentifier)
            }
        }

        if(grailsApplication.config.ccms.facebookForceLocale){
            session.localeIdentifier = grailsApplication.config.ccms.facebookForceLocale

            if(logging){
                log.info("Locale is forced to: " + grailsApplication.config.ccms.facebookForceLocale)
            }
        }

        if(logging){
            log.info("success: " + success)
            log.info("Redirecting to: " + (success ? (session?.ageCheckerRedirectUri ?: '/') : (grailsApplication.config.ccms.underAgeUri ?: '/ageChecker/underAge')))
            log.info("End of Facebook auth")
        }

        redirect uri: success ? (session?.ageCheckerRedirectUri ?: '/') : (grailsApplication.config.ccms.underAgeUri ?: '/ageChecker/underAge')
    }
}
