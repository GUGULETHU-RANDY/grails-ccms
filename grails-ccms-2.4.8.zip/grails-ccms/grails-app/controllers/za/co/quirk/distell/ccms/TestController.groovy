package za.co.quirk.distell.ccms

import za.co.quirk.distell.ccms.bean.DistellCCMSConsumer
import za.co.quirk.distell.ccms.service.CCMSConsumerService

class TestController {

    def grailsApplication

    def index() {
        CCMSConsumerService service = new CCMSConsumerService(grailsApplication.config.ccms.consumerKey, grailsApplication.config.ccms.consumerSecret, false)

        DistellCCMSConsumer consumer = new DistellCCMSConsumer(emailAddress: 'test@quirk.biz', password: 'ilovequirk', source: 'test', contactNumber: '0725481972')
        service.send(consumer)

        consumer = service.getConsumerDetails('test@quirk.biz')
        println 'Mobile number: ' + consumer.contactNumber

        String sessionId = service.loginConsumer('test@quirk.biz', 'ilovequirk')

        render sessionId

        if(sessionId) render service.sendSms(sessionId, '115a068e-4197-11e4-8bbc-000c2935cefa')
    }
}
