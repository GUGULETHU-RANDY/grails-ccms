package za.co.quirk.distell.ccms

import za.co.quirk.distell.ccms.util.AgeCheckerUtils

class AgeCheckerController {

    def ageCheckerService
    def facebookService

    final static String defaultInvalidDobMessage = "Enter a valid date of birth"

    def index = {
        if (request.post) {
            def mobileOver18Flag = (String) params.mobileOver18
            if (mobileOver18Flag && mobileOver18Flag?.toLowerCase() == 'yes') {
                session.ageCheckerBoolean = true
                session.ageCheckerCountry = params.country
                session.localeIdentifier = params.country

                redirect uri: session.ageCheckerRedirectUri ?: '/'
                return false
            } else if (mobileOver18Flag && mobileOver18Flag?.toLowerCase() == 'no') {
                redirect uri: grailsApplication.config.ccms.underAgeUri ?: '/ageChecker/underAge'
                return false
            }

            try {
                if (ageCheckerService.isLegit(params.dobYear, params.dobMonth, params.dobDay, params.country)) {
                    session.ageCheckerDob = AgeCheckerUtils.getDateFromYMD(params.dobYear, params.dobMonth, params.dobDay)
                    session.ageCheckerCountry = params.country
                    session.localeIdentifier = params.country

                    def redirectUri = session.ageCheckerRedirectUri;

                    if (!redirectUri && (request.queryString && request.queryString.size() > 0)) {

                        redirectUri = "?${request.queryString}";

                        flash.redirectUri = redirectUri;
                    } else if (!redirectUri && !request.queryString) {
                        redirectUri = '/';
                    }

                    redirect uri: redirectUri;

                    return false
                } else {
                    redirect uri: grailsApplication.config.ccms.underAgeUri ?: '/ageChecker/underAge'
                    return false
                }
            }
            catch (IllegalArgumentException e) {
                flash.message = grailsApplication.config.ccms.invalidDobMessage ?: defaultInvalidDobMessage
            }
        } else {
            if (grailsApplication.config.ccms?.useGeoIp) {
                withLocation { location ->
                    params.country = location?.countryCode
                }
            }

            if (params.mobileOver18Flag && params.mobileOver18Flag == 'no') {//Mobile handling for no option - GET
                redirect uri: grailsApplication.config.ccms.underAgeUri ?: '/ageChecker/underAge'
                return false
            }
        }

        def fbConnectUrl = facebookService?.getOAuthUrlStep1()
        [fbConnectUrl: fbConnectUrl]
    }

    def underAge = {}
}
