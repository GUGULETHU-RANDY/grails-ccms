General Information
-------------------
- Project: grails-ccms
- Description: Provides functionality to ease integration with the CCMS
- Technologies: Grails, CCMS

Testing
-------
- All tests should be run and pass before every publish
- grails test-app - Grails unit tests cover utility code

## Requirements
- Java 7
- Grails 2.0.4

### SDKMAN
Use SDKMAN! To easily switch versions
https://sdkman.io/

### Java
`sdk install java 7.0.222-zulu`
`sdk use java 7.0.222-zulu`

### Grails
`sdk install grails 2.0.4`
`sdk use grails 2.0.4`

### Installing Plugin to Local Repo
`grails run-app`
`grails install-plugin grails-grails-ccms-2.4.8.zip`