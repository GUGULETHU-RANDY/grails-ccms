import za.co.quirk.distel.ccms.grailsservice.AgeCheckerService
import za.co.quirk.distel.ccms.grailsservice.FacebookService

class GrailsCcmsGrailsPlugin {
    def version = "2.4.8"
    def grailsVersion = "2.0 > *"
    def dependsOn = [:]
    def pluginExcludes = [
            "grails-app/views/error.gsp",
            "grails-app/views/error.gsp"
    ]

    def title = "Grails Ccms Plugin"
    def author = "Grant Wright"
    def authorEmail = "grant.wright@quirk.biz"
    def description = '''\
Includes the qccms Java wrapper for the Distell CCMS, and functionality for submitting consumers to the CCMS
'''

    def documentation = "http://wiki.quirk.co.za/"
    def organization = [ name: "Quirk", url: "http://www.quirk.biz" ]
    def scm = [ url: "https://bitbucket.org/quirkagency/tech.grails-ccms/" ]

    def doWithSpring = {
        if (application.config?.ccms?.consumerKey instanceof String &&
                application.config?.ccms?.consumerSecret instanceof String ) {

            ageCheckerService(AgeCheckerService) {
                grailsApplication = ref('grailsApplication')
            }

            facebookService(FacebookService) {
                grailsApplication = ref('grailsApplication')
            }
        }
    }
}
