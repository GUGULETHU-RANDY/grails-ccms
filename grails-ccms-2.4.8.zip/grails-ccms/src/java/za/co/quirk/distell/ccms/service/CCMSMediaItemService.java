package za.co.quirk.distell.ccms.service;

import net.oauth.client.OAuthResponseMessage;
import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.bean.DistellResponse;
import za.co.quirk.distell.ccms.bean.MediaForUpload;
import za.co.quirk.distell.ccms.bean.MediaItem;
import za.co.quirk.distell.ccms.util.CCMSUtils;
import za.co.quirk.distell.ccms.util.RestUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CCMSMediaItemService extends DistellRestService {
    public CCMSMediaItemService(String consumerKey, String consumerSecret, boolean staging) {
        super(consumerKey, consumerSecret, staging);
    }

    public List<MediaItem> getMediaItemsFromCCMS() {
        return getMediaItemsFromCCMS(null);
    }
    public List<MediaItem> getMediaItemsForGalleryFromCCMS(String galleryName) {
        Map args = new HashMap();
        args.put("gallery", galleryName);
        return getMediaItemsFromCCMS(args);
    }
    public List<MediaItem> getMediaItemsFromCCMS(Map arguments) {

        List<MediaItem> mediaItems = new ArrayList<MediaItem>();

        String response = makeCcmsCall("media", null, arguments);
        if ("error".equals(response)) return mediaItems;

        try {
            JSONObject json = new JSONObject(response);
            JSONArray result = json.getJSONArray("result");
            for (int i = 0; i < result.length(); i++) {
                JSONObject mediaItemJson = result.getJSONObject(i);
                MediaItem mediaItem = CCMSUtils.createMediaItemFromJson(mediaItemJson);
                mediaItems.add(mediaItem);
            }
        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: ", e);
        }

        return mediaItems;
    }
    public MediaItem getMediaItemFromCCMS(String guid) {

        String response = makeCcmsCall("media", guid, null, false);
        if ("error".equals(response)) return null;

        try {
            JSONObject json = new JSONObject(response);
            JSONObject mediaItemJson = json.getJSONObject("result");
            return CCMSUtils.createMediaItemFromJson(mediaItemJson);
        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: ", e);
        }

        return null;
    }
    public String saveToCCMS(MediaForUpload media) {

        JSONObject json = new JSONObject();
        try {
            byte[] bytes = media.getImage().getBytes();
            Base64 base64 = new Base64();
            String encoded = base64.encodeToString(bytes);

            json.put("name", media.getName());
            json.put("description", media.getDescription());
            json.put("image", encoded);
        }
        catch (JSONException e) {
            log.error("JSONException constructing media submission to CCMS", e);
        }

        OAuthResponseMessage response;

        try {
            response = post(json.toString().getBytes("UTF-8"), "media");
        } catch (Exception e) {
            log.error("Failed to comms to Distell server", e);

            return null;
        }

        DistellResponse distellResponse = RestUtils.decipherResponse(response);

        if (distellResponse == null || distellResponse.getResult() == null) {
            log.error("CCMS returned a fail response on media submission (see response above)");

            return null;
        }

        try {
            JSONObject jsonObject = new JSONObject(distellResponse.getResult());

            return (String) jsonObject.get("uri");
        }
        catch (JSONException e) {}

        return null;
    }
}
