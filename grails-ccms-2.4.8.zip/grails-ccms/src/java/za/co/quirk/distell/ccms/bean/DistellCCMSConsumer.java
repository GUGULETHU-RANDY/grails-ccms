/**
 * 12 Oct 2011
 */
package za.co.quirk.distell.ccms.bean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.util.AgeChecker;
import za.co.quirk.distell.ccms.util.CCMSUtils;
import za.co.quirk.distell.ccms.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.*;

public class DistellCCMSConsumer {
    Long id;
    String emailAddress;
    String firstName;
    String lastName;
    String contactNumber;
    private String source;
    String nps;
    private String password;
    private Boolean emailOptin;
    private Boolean smsOptin;
    private String country;
    private String region;
    private String city;
    private String suburb;
    private String dob;
    private String gender;
    private String idNumber;
    private String title;
    private String pictureUri;
    private String facebookId;
    private String twitterId;
    private Boolean active;
    private HashMap<String, Object> brandFields;
    private boolean allowMobileLength11 = false;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getEmailAddress() {
        return emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getContactNumber() {
        return contactNumber;
    }
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }
    public void removeContactNumberInternationalCode() {
        if(this.contactNumber != null) {
            this.contactNumber = this.contactNumber.replace("+27","0");
        }
    }

    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public Boolean getEmailOptin() {
        return emailOptin;
    }
    public void setEmailOptin(Boolean emailOptin) {
        this.emailOptin = emailOptin;
    }
    public Boolean getSmsOptin() {
        return smsOptin;
    }
    public void setSmsOptin(Boolean smsOptin) {
        this.smsOptin = smsOptin;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public String getRegion() {
        return region;
    }
    public void setRegion(String region) {
        this.region = region;
    }
    public String getCity() { return city; }
    public void setCity(String city) {
        this.city = city;
    }
    public String getSuburb() { return suburb; }
    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }
    public String getDob() {
        return dob;
    }
    public void setDob(String dob) {
        this.dob = dob;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public String getIdNumber() {
        return idNumber;
    }
    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getPictureUri() {
        return pictureUri;
    }
    public void setPictureUri(String pictureUri) {
        this.pictureUri = pictureUri;
    }
    public String getFacebookId() {
        return facebookId;
    }
    public void setFacebookId(String facebookId) {
        this.facebookId = facebookId;
    }
    public String getTwitterId() {
        return twitterId;
    }
    public void setTwitterId(String twitterId) {
        this.twitterId = twitterId;
    }
    public Boolean getActive() {
        return active;
    }
    public void setActive(Boolean active) {
        active = active;
    }
    public String getNps() {
        return nps;
    }
    public void setNps(String nps) {
        this.nps = nps;
    }
    public HashMap<String, Object> getBrandFields() {
        return brandFields;
    }
    public void setBrandFields(HashMap<String, Object> brandFields) {
        Set<String> keys = brandFields.keySet();

        for(String key : keys) {
            this.setBrandField(key, brandFields.get(key));
        }
    }

    public void setBrandField(String key, Object value) {
        if(this.brandFields == null) {
            this.brandFields = new HashMap<String, Object>();
        }

        Object currentFieldValue = this.getBrandField(key);
        if(currentFieldValue != null && currentFieldValue instanceof JSONArray) {
            ((JSONArray) currentFieldValue).put(value);
        }
        else {
            this.brandFields.put(key, value);
        }
    }

    public Object getBrandField(String key) {
        if(this.brandFields != null) {
            return this.brandFields.get(key);
        }

        return null;
    }

    public boolean isAllowMobileLength11() {
        return allowMobileLength11;
    }

    public void setAllowMobileLength11(boolean allowMobileLength11) {
        this.allowMobileLength11 = allowMobileLength11;
    }

    public Map validate() {
        Map ret = new HashMap();

        if (StringUtils.isEmpty(getSource())) {
            ret.put("fldSource", "Source must be set");
        }

        if (StringUtils.isEmpty(getContactNumber()) && (StringUtils.isEmpty(getEmailAddress()) || !StringUtils.validateEmailAddress(getEmailAddress()))) {
            ret.put("fldEmailAddress", "Enter a valid email address or mobile number");
            ret.put("fldContactNumber", "Enter a valid contact number or email address");

        }
        if (!StringUtils.isEmpty(getDob())) {
            if (dob.length() == 10) {
                String pattern = "yyyy-MM-dd";
                SimpleDateFormat format = new SimpleDateFormat(pattern);
                try {
                    Date dob = format.parse(getDob());
                    AgeChecker ac = new AgeChecker();
                    if (!ac.isOlderThanOrEqualAge(dob)) {
                        ret.put("fldDob", "Sorry, you are not of legal drinking age");
                    }
                } catch (Exception e) {
                    ret.put("fldDob", "Enter your date of birth");
                }
            } else {
                ret.put("fldDob", "Enter your date of birth in the format yyyy-mm-dd");
            }

            if (StringUtils.isEmpty(getCountry())) {//Country is required if dob is set
                ret.put("fldCountry", "Enter your country");
            }
        }
        if (!StringUtils.isEmpty(getIdNumber())) {
            if (getIdNumber().length() != 13) {
                ret.put("fldIdNumber", "Enter a valid id number");
            } else {
                try {
                    Long.parseLong(getIdNumber());
                } catch (NumberFormatException e) {
                    ret.put("fldIdNumber", "Enter a valid id number");
                }
            }
        }
        if (!StringUtils.isEmpty(getTitle())) {
            if (getTitle().length() > 45) {
                ret.put("fldTitle", "Title must be shorter than 45 characters");
            }
        }
        if (!StringUtils.isEmpty(getGender())) {
            if (!("M".equals(getGender()) || "F".equals(getGender()))) {
                ret.put("fldGender", "Enter your gender");
            }
        }
        if(!StringUtils.isEmpty(getCountry())) {
            if(getCountry().length() != 2) {
                ret.put("fldCountry", "Enter a valid country");
            }
            if(StringUtils.isEmpty(getDob())) {//DOB is required if country is set
                ret.put("fldDob", "Enter your date of birth");
            }
        }
        if (!StringUtils.isEmpty(getRegion())) {
            if (getCountry() != null && getCountry().toLowerCase().equals("za")) {
                String[] regionsForZa = {"WC", "EC", "FS", "GP", "GP-P", "GP-S", "KZN", "LM", "MP", "NC", "NW"};
                List<String> wordList = Arrays.asList(regionsForZa);

                if (!wordList.contains(getRegion())) {
                    ret.put("fldRegion", "Enter your region");
                }
            }
        }
        if(!StringUtils.isEmpty(getNps())) {
            try {
                Integer.parseInt(getNps());
            }catch (Exception e){
                ret.put("fldNps", "Enter your NPS.");
            }
        }
        if (!StringUtils.isEmpty(getContactNumber())) {
            if(getContactNumber().length() > 20) {
                ret.put("fldContactNumber", "Enter a valid contact number.");
            }
        }

        return ret;
    }

    @Override
    public String toString() {
        String result = "id:" + id;
        result = result + ",firstName: " + firstName;
        result = result + ",lastName: " + lastName;
        result = result + ",emailAddress: " + (emailAddress != null ? emailAddress : "null");
        result = result + ",contactNumber: " + (contactNumber != null ? contactNumber : "null");
        result = result + ",source: " + source;
        result = result + ",password: " + (password != null ? "is set" : "not set");
        result = result + ",emailOptin: " + (emailOptin != null ? emailOptin : "null");
        result = result + ",smsOptin: " + (smsOptin != null ? smsOptin : "null");
        result = result + ",country: " + country;
        result = result + ",city: " + city;
        result = result + ",suburb: " + suburb;
        result = result + ",dob: " + dob;
        result = result + ",nps: " + (nps != null ? nps : "null");

        return result;
      
    }
    public JSONObject toJson() {
        return toJson(false);
    }
    public JSONObject toJson(boolean update) {

        JSONObject json = new JSONObject();

        try {
            if (this.getId() != null && this.getId() != 0) {
                json.put("id", this.id);
            }
            if (this.getFirstName() != null) {
                json.put("first_name", this.getFirstName());
            }
            if (this.getLastName() != null) {
                json.put("last_name", this.getLastName());
            }
            if (this.getEmailAddress() != null) {
                json.put("email", this.getEmailAddress());
            }
            if (this.getContactNumber() != null) {
                json.put("mobile", this.getContactNumber());
            }
            if (this.getSource() != null) {
                json.put("source", this.getSource());
            }
            if (this.getPassword() != null) {
                json.put("password", this.getPassword());
            }
            if (!StringUtils.isEmpty(this.getIdNumber())) {
                json.put("id_number", this.getIdNumber());
            }
            if (!StringUtils.isEmpty(this.getTitle())) {
                json.put("title", this.getTitle());
            }
            if (this.getGender() != null) {
                json.put("gender", this.getGender());
            }
            if (this.getDob() != null) {
                json.put("dob", this.getDob());
            }
            if (this.getCountry() != null) {
                json.put("country", this.getCountry());
            }
            if (!StringUtils.isEmpty(this.getRegion())) {
                json.put("region", this.getRegion());
            }
            if (this.getCity() != null) {
                json.put("address_line_city", this.getCity());
            }
            if (this.getSuburb() !=null) {
                json.put("address_line_subburb", this.getSuburb());
            }
            if (this.getActive() != null) {
                json.put("is_active", this.getActive() ? "1" : "0");
            }
            if (!StringUtils.isEmpty(this.getPictureUri())) {
                json.put("picture_uri", this.getPictureUri());
            }
            if (!StringUtils.isEmpty(this.getFacebookId())) {
                json.put("facebook_id", this.getFacebookId());
            }
            if (this.getTwitterId() != null) {
                json.put("twitter_id", this.getTwitterId());
            }
            if (this.getEmailOptin() != null) {
                json.put("email_opt", this.getEmailOptin() ? 1 : 0);
            }
            if (this.getSmsOptin() != null) {
                json.put("mobile_opt", this.getSmsOptin() ? 1 : 0);
            }
            if (this.getNps() !=null) {
                json.put("nps_score", this.getNps());
            }

            if (this.getBrandFields() != null) {
                json.put("brandFields", new JSONObject(this.getBrandFields()));
            }
            if (update) {
                json.put("emailUri", this.getEmailAddress());
            }
        } catch (JSONException e) {
            return null;
        }

        return json;
    }

    public static DistellCCMSConsumer fromJson(JSONObject json) {
        return CCMSUtils.createConsumerFromJson(json);
    }
}
