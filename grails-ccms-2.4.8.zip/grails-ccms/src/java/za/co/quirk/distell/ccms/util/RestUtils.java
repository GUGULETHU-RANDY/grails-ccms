/**
 * 05 Dec 2011
 */
package za.co.quirk.distell.ccms.util;

import net.oauth.client.OAuthResponseMessage;
import net.oauth.http.HttpResponseMessage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.bean.DistellResponse;
import za.co.quirk.distell.ccms.service.DistellRestService;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

public class RestUtils {

    public static final Log log = LogFactory.getLog(DistellRestService.class);
    public static DistellResponse decipherResponse(OAuthResponseMessage response) {

        DistellResponse distellResponse = new DistellResponse();

        if (response == null) {
            DistellResponse networkErrorReponse = new DistellResponse();
            networkErrorReponse.setSuccess(false);
            networkErrorReponse.setError("Network error");
            networkErrorReponse.setTimeStamp(new Date().toString());

            return networkErrorReponse;
        }

        try {
            HttpResponseMessage http = response.getHttpResponse();
            JSONObject object = null;

            if (http.getBody() != null) {

                InputStream inputStream = http.getBody();

                BufferedInputStream bis = new BufferedInputStream(inputStream);
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                int result = bis.read();

                while (result != -1) {
                    byte b = (byte) result;
                    outputStream.write(b);
                    result = bis.read();
                }

                object = new JSONObject(outputStream.toString());
            }

            distellResponse.setStatusCode(http.getStatusCode());

            if (object != null) {
                log.debug("Response JSON: " + object.toString());
                distellResponse.setSuccess(object.getBoolean("success"));
                if (distellResponse.isSuccessful()) {
                    if (object.getString("success").contains("true")){
                        distellResponse.setResult(object.getString("success")); //This is a hack they keep changing their response!!!!
                    } else {
                        distellResponse.setResult(object.getString("success"));
                    }
                } else {
                    distellResponse.setError(object.getString("error"));
                }
            }

        } catch (IOException e) {
            log.error("Error retrieving http response from CCMS", e);
            distellResponse.setSuccess(false);
            distellResponse.setError(e.getMessage());

        } catch (JSONException e) {
            log.error("Error parsing response String to JSONObject", e);
            distellResponse.setSuccess(false);
            distellResponse.setError(e.getMessage());
        }

        return distellResponse;
    }

    public static String isSuccessfulResult(DistellResponse response) {
        try {
            if (response.isSuccessful()) {
                return "success";
            } else {
                log.debug("CCMS returned call success but fail result - consumer not added to CCMS (see response JSON above)");
                return "error: " + response.getError();
            }
        } catch (Exception e) {
            log.error("There was an error reading the server response", e);
            return "error: There was an error reading the server response" + e;
        }
    }
}
