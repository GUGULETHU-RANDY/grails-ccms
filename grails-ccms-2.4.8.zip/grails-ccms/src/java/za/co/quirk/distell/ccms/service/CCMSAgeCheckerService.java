package za.co.quirk.distell.ccms.service;

import java.util.HashMap;
import java.util.Map;

import groovy.util.logging.Log4j;
import org.joda.time.DateTime;
import org.json.JSONObject;
import org.json.JSONException;

@Log4j
public class CCMSAgeCheckerService extends DistellRestService {

    public CCMSAgeCheckerService(String consumerKey, String consumerSecret, boolean staging) {
        super(consumerKey, consumerSecret, staging);
    }

    public Boolean performRemoteAgeCheck(DateTime birthDate, String countryCode) {
        Map<String, String> arguments = new HashMap<String, String>();
        arguments.put("code", countryCode);
        arguments.put("dob", birthDate.toString("yyyy-MM-dd"));

        String response = this.makeCcmsCall("agescreener", null, arguments, true);

        try {
            JSONObject json = new JSONObject(response);
            if(!json.optBoolean("success", false)) {
                return false;
            }

            JSONObject result = json.optJSONObject("result");
            if(result != null) {
                return result.optBoolean("drinkingAllowed", false);
            }

            return false;
        }
        catch (JSONException e){
            log.error("JSONException parsing response from CCMS for age checker", e);
            return false;
        }
    }
}
