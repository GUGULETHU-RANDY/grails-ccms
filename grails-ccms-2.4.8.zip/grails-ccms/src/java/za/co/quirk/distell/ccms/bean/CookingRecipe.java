package za.co.quirk.distell.ccms.bean;

import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.util.CCMSUtils;

import java.util.ArrayList;
import java.util.List;

public class CookingRecipe {
    String guid;
    String title;
    String body;
    String description;
    String userSessionId;
    Boolean isActive;
    Boolean isRatingAllowed;
    Long skillLevel;
    Long serves;
    String imageUrl;
    String thumbUrl64;
    String thumbUrl128;
    String thumbUrl256;

    ArrayList<String> ingredients = new ArrayList<String>();

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getUserSessionId() {
        return userSessionId;
    }

    public void setUserSessionId(String userSessionId) {
        this.userSessionId = userSessionId;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public Boolean getRatingAllowed() {
        return isRatingAllowed;
    }

    public void setRatingAllowed(Boolean ratingAllowed) {
        isRatingAllowed = ratingAllowed;
    }

    public Long getSkillLevel() {
        return skillLevel;
    }

    public void setSkillLevel(Long skillLevel) {
        this.skillLevel = skillLevel;
    }

    public Long getServes() {
        return serves;
    }
    public void setServes(Long serves) {
        this.serves = serves;
    }
    
    
    public String getImageUrl() {
        return this.imageUrl;
    }
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getThumbnail64Url() {
        return this.thumbUrl64;
    }
    public void setThumbnail64Url(String thumb64Url) {
        this.thumbUrl64 = thumb64Url;
    }

    public String getThumbnail128Url() {
        return this.thumbUrl128;
    }
    public void setThumbnail128Url(String thumb128Url) {
        this.thumbUrl128 = thumb128Url;
    }

    public String getThumbnail256Url() {
        return this.thumbUrl256;
    }
    public void setThumbnail256Url(String thumb256Url) {
        this.thumbUrl256 = thumb256Url;
    }

    public List<String> getIngredients() {
        return this.ingredients;
    }

    public JSONObject toJson() {
        JSONObject json = new JSONObject();

        try {
            if(this.guid != null ) {
                json.put("guid", this.guid);
            }
            if(this.title != null) {
                json.put("title", this.title);
            }
            if(this.body != null) {
                json.put("body", this.body);
            }
            if(this.description != null) {
                json.put("description", this.description);
            }
            if(this.userSessionId != null) {
                json.put("session_id", this.getUserSessionId());
            }
            if(this.userSessionId == null) {
                json.put("session_id", "h0g5JPDTH6tYyJGs");
            }
            if(isActive != null) {
                json.put("is_active", this.isActive ? "1" : "0");
            }
            if(isRatingAllowed != null) {
                json.put("is_rating_allowed", this.isRatingAllowed ? true : false);
            }
            if(skillLevel != null) {
                json.put("skill_level", this.skillLevel);
            }
            if(serves != null) {
                json.put("serves", this.serves);
            }
            
            if(this.ingredients != null && this.ingredients.size() > 0) {
                json.put("ingredient", this.ingredients.toArray());
            }
        }
        catch (JSONException e) {
            return null;
        }

        return json;
    }

    public static CookingRecipe fromJson(JSONObject json) {
        return CCMSUtils.createCookingRecipeFromJson(json);
    }
}
