package za.co.quirk.distell.ccms.enums;

public enum PageType
{
  PAGE, EVENT, ARTICLE, BLOG;

  public static PageType fromString( String s )
  {
    for( PageType pageType : PageType.values() )
    {
      if( ( pageType.name().toString().substring(0,1).toUpperCase() + pageType.name().toString().substring(1).toLowerCase() ).equals( s ) )
      {
        return pageType;
      }
    }
    return null;
  }
}