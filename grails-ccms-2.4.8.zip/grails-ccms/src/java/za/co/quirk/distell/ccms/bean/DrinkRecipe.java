package za.co.quirk.distell.ccms.bean;

import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.util.CCMSUtils;

public class DrinkRecipe {
    String guid;
    Long categoryId;
    Long glassId;
    String title;
    String body;
    String description;
    String userSessionId;
    Boolean isActive;
    Boolean isRatingAllowed;
    Long skillLevel;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public Long getGlassId() {
        return glassId;
    }

    public void setGlassId(Long glassId) {
        this.glassId = glassId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getUserSessionId() {
        return userSessionId;
    }

    public void setUserSessionId(String userSessionId) {
        this.userSessionId = userSessionId;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public Boolean getRatingAllowed() {
        return isRatingAllowed;
    }

    public void setRatingAllowed(Boolean ratingAllowed) {
        isRatingAllowed = ratingAllowed;
    }

    public Long getSkillLevel() {
        return skillLevel;
    }

    public void setSkillLevel(Long skillLevel) {
        this.skillLevel = skillLevel;
    }

    public JSONObject toJson() {
        JSONObject json = new JSONObject();

        try {
            if(this.guid != null ) {
                json.put("guid", this.guid);
            }
            if(this.categoryId != null ) {
                json.put("category_id", this.categoryId);
            }
            if(this.glassId != null ) {
                json.put("glass_id", this.glassId);
            }
            if(this.title != null) {
                json.put("title", this.title);
            }
            if(this.body != null) {
                json.put("body", this.body);
            }
            if(this.description != null) {
                json.put("description", this.description);
            }
            if(this.userSessionId != null) {
                json.put("session_id", this.getUserSessionId());
            }
            if(isActive != null) {
                json.put("is_active", this.isActive ? "1" : "0");
            }
            if(isRatingAllowed != null) {
                json.put("is_rating_allowed", this.isRatingAllowed ? true : false);
            }
            if(skillLevel != null) {
                json.put("skill", this.skillLevel);
            }
        }
        catch (JSONException e) {
            return null;
        }

        return json;
    }

    public static DrinkRecipe fromJson(JSONObject json) {
        return CCMSUtils.createDrinkRecipeFromJson(json);
    }
}
