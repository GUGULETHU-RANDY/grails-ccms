package za.co.quirk.distell.ccms.service;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.bean.Event;
import za.co.quirk.distell.ccms.bean.EventWithGallery;
import za.co.quirk.distell.ccms.util.CCMSUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CCMSEventService extends DistellRestService {
    public CCMSEventService(String consumerKey, String consumerSecret, boolean staging) {
        super(consumerKey, consumerSecret, staging);
    }

    public List<Event> getEventsFromCCMS() {
        return getEventsFromCCMS(null);
    }
    public List<Event> getEventsFromCCMS(Map arguments) {

        List<Event> events = new ArrayList<Event>();

        String response = makeCcmsCall("event", null, arguments);
        if ("error".equals(response)) return events;

        try {
            JSONObject json = new JSONObject(response);
            JSONArray result = json.getJSONArray("result");
            for (int i = 0; i < result.length(); i++) {
                JSONObject eventJson = result.getJSONObject(i);
                Event event = new Event();
                CCMSUtils.createEventFromJson(eventJson, event);
                events.add(event);
            }
        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: ", e);
        }

        return events;
    }

    public Event getEventFromCCMS(String guid) {

        String response = makeCcmsCall("event", guid, null, false);
        if ("error".equals(response)) return null;

        try {
            JSONObject json = new JSONObject(response);
            JSONArray result = json.getJSONArray("result");
            Event ret = new Event();
            CCMSUtils.createEventFromJson(result.getJSONObject(0), ret);
            return ret;
        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: ", e);
        }

        return null;
    }

    public EventWithGallery getEventWithGalleryFromCCMS(String guid) {
        EventWithGallery event = new EventWithGallery();

        String response = makeCcmsCall("event", guid, null);
        if ("error".equals(response)) return null;

        try {
            JSONObject json = new JSONObject(response);
            JSONArray result = json.getJSONArray("result");
            CCMSUtils.createEventFromJson(result.getJSONObject(0), event);
            CCMSMediaItemService mediaItemService = new CCMSMediaItemService(getConsumerKey(), getConsumerSecret(), getStaging());

            event.setGallery(mediaItemService.getMediaItemsForGalleryFromCCMS(event.getGalleryName()));
        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: ", e);
        }

        return event;
    }
}

