package za.co.quirk.distell.ccms.bean;

import java.util.Date;

public class Event
{
  private String guid;
  private String title;
  private String blurb;
  private Date start;
  private Date end;
  private String galleryName;
  private String galleryDescription;
  private String description;
  private String bookingUrl;
  private String attendance;
  private String location;
  private String locationLatitude;
  private String locationLongitude;
  private Date created;
  private Date updated;
  private String tags;
  private String imageUrl;

  public String getGuid()
  {
    return guid;
  }

  public void setGuid( String guid )
  {
    this.guid = guid;
  }

  public String getTitle()
  {
    return title;
  }

  public void setTitle( String title )
  {
    this.title = title;
  }

  public String getBlurb()
  {
    return blurb;
  }

  public void setBlurb( String blurb )
  {
    this.blurb = blurb;
  }

  public Date getStart()
  {
    return start;
  }

  public void setStart( Date start )
  {
    this.start = start;
  }

  public Date getEnd()
  {
    return end;
  }

  public void setEnd( Date end )
  {
    this.end = end;
  }

  public String getGalleryName()
  {
    return galleryName;
  }

  public void setGalleryName( String galleryName )
  {
    this.galleryName = galleryName;
  }

  public String getGalleryDescription()
  {
    return galleryDescription;
  }

  public void setGalleryDescription( String galleryDescription )
  {
    this.galleryDescription = galleryDescription;
  }

  public String getDescription()
  {
    return description;
  }

  public void setDescription( String description )
  {
    this.description = description;
  }

  public String getBookingUrl()
  {
    return bookingUrl;
  }

  public void setBookingUrl( String bookingUrl )
  {
    this.bookingUrl = bookingUrl;
  }

  public String getAttendance()
  {
    return attendance;
  }

  public void setAttendance( String attendance )
  {
    this.attendance = attendance;
  }

  public String getLocation()
  {
    return location;
  }

  public void setLocation( String location )
  {
    this.location = location;
  }

  public String getLocationLatitude()
  {
    return locationLatitude;
  }

  public void setLocationLatitude( String locationLatitude )
  {
    this.locationLatitude = locationLatitude;
  }

  public String getLocationLongitude()
  {
    return locationLongitude;
  }

  public void setLocationLongitude( String locationLongitude )
  {
    this.locationLongitude = locationLongitude;
  }

  public Date getCreated()
  {
    return created;
  }

  public void setCreated( Date created )
  {
    this.created = created;
  }

  public Date getUpdated()
  {
    return updated;
  }

  public void setUpdated( Date updated )
  {
    this.updated = updated;
  }

  public String getTags()
  {
    return tags;
  }

  public void setTags( String tags )
  {
    this.tags = tags;
  }

  public String getImageUrl()
  {
    return imageUrl;
  }

  public void setImageUrl( String imageUrl )
  {
    this.imageUrl = imageUrl;
  }
}
