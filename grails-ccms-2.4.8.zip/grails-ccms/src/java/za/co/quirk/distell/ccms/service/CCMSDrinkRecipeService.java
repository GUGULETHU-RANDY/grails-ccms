package za.co.quirk.distell.ccms.service;

import net.oauth.client.OAuthResponseMessage;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import za.co.quirk.distell.ccms.bean.DrinkRecipe;
import za.co.quirk.distell.ccms.bean.DistellResponse;
import za.co.quirk.distell.ccms.util.RestUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CCMSDrinkRecipeService extends DistellRestService {
    public CCMSDrinkRecipeService(String consumerKey, String consumerSecret, boolean staging) {
        super(consumerKey, consumerSecret, staging);
    }

    public List<DrinkRecipe> getRecipesFromCCMS() {
        return getRecipesFromCCMS(null);
    }

    public List<DrinkRecipe> getRecipesFromCCMS(Map arguments) {

        List<DrinkRecipe> drinkRecipes = new ArrayList<DrinkRecipe>();

        String response = makeCcmsCall("cooking", null, arguments);
        if ("error".equals(response)) return drinkRecipes;

        try {
            JSONObject json = new JSONObject(response);
            JSONArray result = json.getJSONArray("result");
            for (int i = 0; i < result.length(); i++) {
                JSONObject recipeJson = result.getJSONObject(i);
                DrinkRecipe drinkRecipe = DrinkRecipe.fromJson(recipeJson);
                drinkRecipes.add(drinkRecipe);
            }
        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: " + e);
        }

        return drinkRecipes;
    }

    public DrinkRecipe getRecipeFromCCMS(String guid) {

        String response = makeCcmsCall("recipe", guid, null, false);
        if ("error".equals(response)) return null;

        try {
            JSONObject json = new JSONObject(response);
            JSONArray recipeJson = json.getJSONArray("result");
            return  DrinkRecipe.fromJson(recipeJson.getJSONObject(0));

        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: " + e);
        }

        return null;
    }

    public Boolean saveToCCMS(DrinkRecipe drinkRecipe) {

        JSONObject json = drinkRecipe.toJson();

        String url = "drinkrecipe";

        OAuthResponseMessage response;

        try {
            response = post(json.toString().getBytes("UTF-8"), url);
        } catch (Exception e) {
            log.error("Failed to comms to Distell server", e);

            return null;
        }

        DistellResponse distellResponse = RestUtils.decipherResponse(response);

        if (distellResponse == null || distellResponse.getResult() == null || !distellResponse.getResult().equals("{\"success\":true}")) {

            log.error("CCMS returned a fail response on drink recipe submission");

            if(distellResponse != null && distellResponse.getResult() != null) {
                log.error("Response: " + distellResponse.getResult());
            }

            if(distellResponse != null && distellResponse.getError() != null) {
                log.error("Error: " + distellResponse.getError());
            }

            return false;
        }

        return true;
    }
}
