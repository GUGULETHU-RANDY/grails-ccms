package za.co.quirk.distell.ccms.service;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.bean.Page;
import za.co.quirk.distell.ccms.util.CCMSUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CCMSPageService extends DistellRestService {

    public CCMSPageService(String consumerKey, String consumerSecret, boolean staging) {
        super(consumerKey, consumerSecret, staging);
    }

    public List<Page> getPagesFromCCMS() {
        return getPagesFromCCMS(null);
    }
    public List<Page> getPagesFromCCMS(Map arguments) {

        List<Page> pages = new ArrayList<Page>();

        String response = makeCcmsCall("page", null, arguments);
        if ("error".equals(response)) return pages;

        try {
            JSONObject json = new JSONObject(response);
            JSONArray result = json.getJSONArray("result");
            for (int i = 0; i < result.length(); i++) {
                JSONObject pageJson = result.getJSONObject(i);
                Page page = CCMSUtils.createPageFromJson(pageJson);
                pages.add(page);
            }
        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: " + e);
        }

        return pages;
    }
    public Page getPageFromCCMS(String guid) {

        String response = makeCcmsCall("page", guid, null, false);
        if ("error".equals(response)) return null;

        try {
            JSONObject json = new JSONObject(response);
            JSONObject pageJson = json.getJSONObject("result");
            return CCMSUtils.createPageFromJson(pageJson);
        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: ", e);
        }

        return null;
    }
}
