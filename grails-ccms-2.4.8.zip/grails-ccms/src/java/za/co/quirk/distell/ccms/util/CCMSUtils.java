package za.co.quirk.distell.ccms.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.bean.*;
import za.co.quirk.distell.ccms.enums.EntityState;
import za.co.quirk.distell.ccms.enums.PageType;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class CCMSUtils {
    protected static final Log log = LogFactory.getLog(CCMSUtils.class);

    public static DistellCCMSConsumer createConsumerFromJson(JSONObject json) {
        DistellCCMSConsumer consumer = new DistellCCMSConsumer();

        consumer.setId(getLongFromJson(json, "id"));
        consumer.setFirstName(getStringFromJson(json, "first_name"));
        consumer.setLastName(getStringFromJson(json, "last_name"));
        consumer.setEmailAddress(getStringFromJson(json, "email"));
        consumer.setContactNumber(getStringFromJson(json, "mobile"));
        consumer.setSource(getStringFromJson(json, "source"));
        consumer.setPassword(getStringFromJson(json, "password"));
        consumer.setIdNumber(getStringFromJson(json, "id_number"));
        consumer.setTitle(getStringFromJson(json, "title"));
        consumer.setGender(getStringFromJson(json, "gender"));
        consumer.setDob(getStringFromJson(json, "dob"));
        consumer.setCountry(getStringFromJson(json, "country"));
        consumer.setRegion(getStringFromJson(json, "region"));
        consumer.setCity(getStringFromJson(json, "address_line_city"));
        consumer.setSuburb(getStringFromJson(json, "address_line_subburb"));
        consumer.setPictureUri(getStringFromJson(json, "picture_uri"));
        consumer.setFacebookId(getStringFromJson(json, "facebook_id"));
        consumer.setTwitterId(getStringFromJson(json, "twitter_id"));
        consumer.setNps(getStringFromJson(json, "nps_score"));


        try {
            consumer.setEmailOptin("1".equals(getStringFromJson(json, "email_opt")) ? true : false);
            if (!consumer.getEmailOptin()) {
                consumer.setEmailOptin(json.getInt("email_opt") == 1 ? true : false);
            }
        } catch (Exception e) {
        }

        try {
            consumer.setSmsOptin("1".equals(getStringFromJson(json, "mobile_opt")) ? true : false);
            if (!consumer.getSmsOptin()) {
                consumer.setSmsOptin(json.getInt("mobile_opt") == 1 ? true : false);
            }
        } catch (Exception e) {
        }

        try {
            consumer.setActive("1".equals(getStringFromJson(json, "is_active")) ? true : false);
            if (!consumer.getActive()) {
                consumer.setActive(json.getInt("is_active") == 1 ? true : false);
            }
        } catch (Exception e) {
        }

        try {
            JSONObject bf = json.getJSONObject("brandFields");
            if (bf != null) {
                HashMap<String, Object> brandFields = new HashMap();
                Iterator<?> keys = bf.keys();

                while (keys.hasNext()) {
                    String key = (String) keys.next();
                    brandFields.put(key, bf.getString(key));
                }

                consumer.setBrandFields(brandFields);
            }
        } catch (Exception e) {
        }

        return consumer;
    }

    public static Page createPageFromJson(JSONObject json) {
        Page page = new Page();

        try {
            page.setGuid(getStringFromJson(json, "guid"));
            page.setTitle(getStringFromJson(json, "title"));
            page.setKeywords(getStringFromJson(json, "keywords"));
            page.setDescription(getStringFromJson(json, "description"));
            page.setExcerpt(getStringFromJson(json, "excerpt"));
            page.setCommentingAllowed("1".equals(getStringFromJson(json, "is_commenting_allowed")) ? true : false);
            page.setRatingAllowed("1".equals(getStringFromJson(json, "is_rating_allowed")) ? true : false);
            page.setState(EntityState.fromString(getStringFromJson(json, "state")));
            page.setType(PageType.fromString(getStringFromJson(json, "type")));
            page.setTags(getStringFromJson(json, "tags"));

            if (json.has("copyboxes")) {
                Map copyBoxes = new HashMap();
                JSONObject copyBoxesJson = json.getJSONObject("copyboxes");
                Iterator<?> keys = copyBoxesJson.keys();

                while (keys.hasNext()) {
                    String key = (String) keys.next();
                    copyBoxes.put(key, copyBoxesJson.getString(key));
                }
                page.setCopyboxes(copyBoxes);
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                if (json.getString("created") != null) {
                    page.setCreated(sdf.parse(json.getString("created")));
                }
                if (json.getString("modified") != null) {
                    page.setModified(sdf.parse(json.getString("modified")));
                }
            } catch (ParseException e) {
                log.error("Exception parsing date values for page from CCMS json: ", e);
            }

            if (json.has("rating")) {
                JSONObject rating = json.getJSONObject("rating");
                page.setRatingTotal(Float.parseFloat(rating.getString("total")));
                page.setRatingAverage(Float.parseFloat(rating.getString("average")));
            }
        } catch (JSONException e) {
            log.error("JSONException retrieving values for page from CCMS json: ", e);
        }

        return page;
    }

    public static MediaItem createMediaItemFromJson(JSONObject json) {
        MediaItem mediaItem = new MediaItem();

        try {
            mediaItem.setGuid(getStringFromJson(json, "guid"));
            mediaItem.setName(getStringFromJson(json, "name"));
            mediaItem.setGallery(getStringFromJson(json, "gallery"));
            mediaItem.setDescription(getStringFromJson(json, "description"));

            mediaItem.setMimeSupertype(getStringFromJson(json, "mime_supertype"));
            mediaItem.setMimeSubtype(getStringFromJson(json, "mime_subtype"));

            try {
                if (json.getString("redemption_points") != null) {
                    mediaItem.setRedemptionPoints(Integer.valueOf(json.getString("redemption_points")));
                } else {
                    mediaItem.setRedemptionPoints(0);
                }
            } catch (Exception e) {
            }

            mediaItem.setAltText(getStringFromJson(json, "alt_text"));
            mediaItem.setExternalUrl(getStringFromJson(json, "external_url"));
            mediaItem.setThumbnail(json.getBoolean("is_thumbnail"));

            mediaItem.setTags(getStringFromJson(json, "tags"));

            try {
                JSONObject links = json.getJSONObject("links");
                mediaItem.setImageUrl(links.getString("imageUrl"));
                mediaItem.setThumbnail128Url(links.getString("thumbUrl128"));
                mediaItem.setFileUrl(links.getString("fileUrl"));
            } catch (JSONException e) {
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            try {
                if (json.getString("created") != null) {
                    mediaItem.setCreated(sdf.parse(json.getString("created")));
                }
                if (json.getString("modified") != null) {
                    mediaItem.setModified(sdf.parse(json.getString("modified")));
                }
            } catch (ParseException e) {
                log.error("Exception parsing date values for mediaItem from CCMS json: ", e);
            }
        } catch (JSONException e) {
            log.error("JSONException retrieving values for mediaItem from CCMS json: ", e);
        }

        return mediaItem;
    }

    public static void createEventFromJson(JSONObject json, Event event) {

        event.setGuid(getStringFromJson(json, "guid"));
        event.setTitle(getStringFromJson(json, "title"));
        event.setBlurb(getStringFromJson(json, "blurb"));
        event.setDescription(getStringFromJson(json, "description"));
        event.setBookingUrl(getStringFromJson(json, "booking_url"));
        event.setTags(getStringFromJson(json, "tags"));

        try {
            JSONObject gallery = json.getJSONObject("gallery");
            event.setGalleryName(gallery.getString("name"));
            event.setGalleryDescription(gallery.getString("description"));
        } catch (Exception e) {
        }

        try {
            JSONObject location = json.getJSONObject("location");
            event.setLocation(location.getString("description"));
            event.setLocationLatitude(location.getString("latitude"));
            event.setLocationLongitude(location.getString("longitude"));
        } catch (Exception e) {
        }

        try {
            JSONObject mediaItem = json.getJSONObject("media_item");
            if (mediaItem != null) {
                JSONObject links = mediaItem.getJSONObject("links");
                event.setImageUrl(links.getString("imageUrl"));
            }
        } catch (JSONException e) {
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        try {
            if (json.getString("start") != null) {
                event.setStart(sdf.parse(json.getString("start")));
            }
            if (json.getString("end") != null) {
                event.setEnd(sdf.parse(json.getString("end")));
            }
            if (json.getString("created") != null) {
                event.setCreated(sdf.parse(json.getString("created")));
            }
            if (json.getString("updated") != null) {
                event.setUpdated(sdf.parse(json.getString("updated")));
            }
        } catch (ParseException e) {
            log.error("Exception parsing date values for event from CCMS json: " + e);
        } catch (JSONException e) {
        }
    }

    public static BrandProduct createBrandProductFromJson(JSONObject json) {
        BrandProduct product = new BrandProduct();

        product.setGuid(getStringFromJson(json, "guid"));
        product.setTitle(getStringFromJson(json, "title"));
        product.setByline(getStringFromJson(json, "byline"));
        product.setServes(getStringFromJson(json, "serves"));
        product.setDescription(getStringFromJson(json, "description"));
        product.setTags(getStringFromJson(json, "tags"));
        product.setNutritionalInformation(getStringFromJson(json, "nutritional_information"));

        try {
            JSONObject category = json.getJSONObject("category");
            product.setCategory(category.getString("title"));

        } catch (JSONException e) {
            log.error("JSONException retrieving media item from Product");
        }
        try {
            JSONObject mediaItem = json.getJSONObject("media_item");
            JSONObject links = mediaItem.getJSONObject("links");
            product.setImageUrl(links.getString("imageUrl"));
        } catch (JSONException e) {
            log.error("JSONException retrieving media item from Product");
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        try {
            if (json.getString("created") != null) {
                product.setCreated(sdf.parse(json.getString("created")));
            }
            if (json.getString("updated") != null) {
                product.setUpdated(sdf.parse(json.getString("updated")));
            }
        } catch (ParseException e) {
        } catch (JSONException e) {
        }

        return product;
    }

    public static CookingRecipe createCookingRecipeFromJson(JSONObject json) {
        CookingRecipe cookingRecipe = new CookingRecipe();

        cookingRecipe.setGuid(getStringFromJson(json, "guid"));
        cookingRecipe.setTitle(getStringFromJson(json, "title"));
        cookingRecipe.setBody(getStringFromJson(json, "body"));
        cookingRecipe.setDescription(getStringFromJson(json, "description"));
        cookingRecipe.setUserSessionId(getStringFromJson(json, "session_id"));

        cookingRecipe.setRatingAllowed("true".equals(getStringFromJson(json, "is_rating_allowed")));
        cookingRecipe.setActive("1".equals(getStringFromJson(json, "is_active")));

        cookingRecipe.setSkillLevel(getLongFromJson(json, "skill_level"));

        cookingRecipe.setServes(getLongFromJson(json, "serves"));

        JSONObject links = json.optJSONObject("links");
        if (links != null) {
            cookingRecipe.setImageUrl(links.optString("imageUrl", ""));
            cookingRecipe.setThumbnail64Url(links.optString("thumbUrl64", ""));
            cookingRecipe.setThumbnail128Url(links.optString("thumbUrl128", ""));
            cookingRecipe.setThumbnail256Url(links.optString("thumbUrl256", ""));
        }

        JSONArray ingredients = json.optJSONArray("ingredient");
        if (ingredients != null) {
            for (int i = 0; i < ingredients.length(); i++) {
                cookingRecipe.getIngredients().add(ingredients.optString(i));
            }
        }

        return cookingRecipe;
    }

    public static DrinkRecipe createDrinkRecipeFromJson(JSONObject json) {
        DrinkRecipe drinkRecipe = new DrinkRecipe();

        drinkRecipe.setGuid(getStringFromJson(json, "guid"));
        drinkRecipe.setCategoryId(getLongFromJson(json, "category_id"));
        drinkRecipe.setGlassId(getLongFromJson(json, "glass_id"));
        drinkRecipe.setTitle(getStringFromJson(json, "title"));
        drinkRecipe.setBody(getStringFromJson(json, "body"));
        drinkRecipe.setDescription(getStringFromJson(json, "description"));

        drinkRecipe.setRatingAllowed("true".equals(getStringFromJson(json, "is_rating_allowed")));
        drinkRecipe.setActive("1".equals(getStringFromJson(json, "is_active")));

        drinkRecipe.setSkillLevel(getLongFromJson(json, "skill_level"));

        return drinkRecipe;
    }

    private static String getStringFromJson(JSONObject json, String key) {
        try {
            String value = json.getString(key);

            return value != "null" ? value : null;
        } catch (Exception e) {
        }
        return null;
    }

    private static Long getLongFromJson(JSONObject json, String key) {
        try {
            return json.getLong(key);
        } catch (Exception e) {
        }
        return null;
    }

}
