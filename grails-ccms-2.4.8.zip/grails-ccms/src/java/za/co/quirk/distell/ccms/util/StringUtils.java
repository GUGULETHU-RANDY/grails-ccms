package za.co.quirk.distell.ccms.util;

import java.util.regex.Pattern;

public class StringUtils {

    public static Boolean isEmpty(String input) {
        return input == null || input.length() == 0;
    }

    public static Boolean validateEmailAddress(String input) {
        if (input == null || input.length() < 1) return false;

        return Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE).matcher(input).find();
    }
}
