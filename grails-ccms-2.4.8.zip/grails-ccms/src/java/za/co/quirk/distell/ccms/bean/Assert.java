package za.co.quirk.distell.ccms.bean;

public class Assert {
    private final String consumerKey = "Flight of the Fish Eagle";
    private final String consumerSecret = "FOFE";
    private String assertResult = "";
    private int testCounter = 0;
    private final String emailRegex = "[a-zA-Z0-9_]";

    private String assertCCMSConsumer(DistellCCMSConsumer consumer){
        assertFirstName(consumer.getFirstName());
        assertLastName(consumer.getLastName());
        assertEmailAddress(consumer.getEmailAddress());
        assertContactNumber(consumer.getContactNumber());
        assertDob(consumer.getDob(), consumer.getCountry());
        assertIdNumber(consumer.getIdNumber());
        assertSource(consumer.getSource());
        assertRegion(consumer.getRegion(), consumer.getCountry());
        assertGender(consumer.getGender());
        assertPassword(consumer.getPassword());

        if (assertResult.equals("")) {
            return "success";
        } else {
            return assertResult + "Number of tests Failed: " + testCounter;
        }
    }

    private String assertCCMSConsumer(){
        DistellCCMSConsumer consumer = new DistellCCMSConsumer();
        consumer.setFirstName("TestFirstName");
        consumer.setLastName("TestSurname");
        consumer.setEmailAddress("test@email.co.za");
        consumer.setContactNumber("0830000000");
        consumer.setSource("TestSource");
        consumer.setCountry("ZA");
        consumer.setDob("1990-01-01");
        consumer.setEmailOptin(true);
        consumer.setSmsOptin(true);
        consumer.setPassword("TestPassword");
        consumer.setRegion("WC");
        consumer.setGender("M");
        consumer.setIdNumber("90010105229088");
        consumer.setTitle("Mr.");
        consumer.setPictureUri("Mr.");
        consumer.setFacebookId("000000000000");
        consumer.setTwitterId("00000000000");
        consumer.setActive(true);


        assertFirstName(consumer.getFirstName());
        assertLastName(consumer.getLastName());
        assertEmailAddress(consumer.getEmailAddress());
        assertContactNumber(consumer.getContactNumber());
        assertDob(consumer.getDob(), consumer.getCountry());
        assertIdNumber(consumer.getIdNumber());
        assertSource(consumer.getSource());
        assertRegion(consumer.getRegion(), consumer.getCountry());
        assertGender(consumer.getGender());
        assertPassword(consumer.getPassword());

        if (assertResult.equals("")) {
            return "success";
        } else {
            return assertResult + "Number of tests Failed: " + testCounter;
        }
    }


    private void assertFirstName(String firstName) {
        if (firstName == null) {
            assertResult = assertResult + "TEST FAILED :: firstName - field is null\n";
            testCounter++;
        } else if (firstName.equals("")) {
            assertResult = assertResult + "TEST FAILED :: firstName - field is empty\n";
            testCounter++;
        }
    }

    private void assertLastName(String lastName) {

        if (lastName == null) {
            assertResult = assertResult + "TEST FAILED :: lastName - field is null\n";
            testCounter++;
        } else if (lastName.equals("")) {
            assertResult = assertResult + "TEST FAILED :: lastName - field is empty\n";
            testCounter++;
        }
    }

    private void assertEmailAddress(String emailAddress) {

        if (emailAddress == null) {
            assertResult = assertResult + "TEST FAILED :: emailAddress - field is null\n";
            testCounter++;
        } else if (emailAddress.equals("")) {
            assertResult = assertResult + "TEST FAILED :: emailAddress - field is empty\n";
            testCounter++;
        }

    }

    private void assertContactNumber(String contactNumber) {
        if (contactNumber.equals("")) {
            assertResult = assertResult + "TEST FAILED :: contactNumber - field is empty\n";
            testCounter++;
        } else if (contactNumber == null) {
            assertResult = assertResult + "TEST FAILED :: contactNumber - field is null\n";
            testCounter++;
        } else if (contactNumber.matches("[^a-zA-Z ]+")) {
            assertResult = assertResult + "TEST FAILED :: contactNumber - Invalid input - Contains characters\n";
            testCounter++;
        }
    }

    private void assertDob(String dob, String country) {

        if (dob == null) {
            assertResult = assertResult + "TEST FAILED :: dob - field is null\n";
            testCounter++;
        } else if (dob.equals("")) {
            assertResult = assertResult + "TEST FAILED :: dob - field is empty\n";
            testCounter++;
        } else {
            if (country == null) {
                assertResult = assertResult + "TEST FAILED :: dob - country field is null\n";
                testCounter++;
            } else if (country.equals("")) {
                assertResult = assertResult + "TEST FAILED :: dob - country field is empty\n";
                testCounter++;
            }
        }

        if (!dob.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
            assertResult = assertResult + "TEST FAILED :: dob - Invalid input - Invalid format\n";
            testCounter++;
        }
    }

    private void assertIdNumber(String idNum) {
        if (idNum == null) {
            assertResult = assertResult + "TEST FAILED :: ID number - field is null\n";
            testCounter++;
        } else if (idNum.equals("")) {
            assertResult = assertResult + "TEST FAILED :: ID number - field is empty\n";
            testCounter++;
        } else if (idNum.length() != 13) {
            assertResult = assertResult + "TEST FAILED :: ID number - Invalid input - Invalid length\n";
            testCounter++;
        } else if (!idNum.matches("[0-9]+")) {
            assertResult = assertResult + "TEST FAILED :: ID number - Invalid input - Field contains invalid characters\n";
            testCounter++;
        }
    }

    private void assertSource(String source) {
        if (source == null) {
            assertResult = assertResult + "TEST FAILED :: source - field is null\n";
            testCounter++;
        } else if (source.equals("")) {
            assertResult = assertResult + "TEST FAILED :: source - field is empty\n";
            testCounter++;
        }
    }

    private void assertRegion(String region, String country) {
        if (region == null) {
            assertResult = assertResult + "TEST FAILED :: region - field is null\n";
            testCounter++;
        }else if (region.equals("")) {
            assertResult = assertResult + "TEST FAILED :: region - field is empty\n";
            testCounter++;
        } else {
            if (country == null) {
                assertResult = assertResult + "TEST FAILED :: region - country field is null\n";
                testCounter++;
            } else if (country.equals("")) {
                assertResult = assertResult + "TEST FAILED :: region - country field is empty\n";
                testCounter++;
            }
        }
    }

    private void assertGender(String gender) {
        if (gender == null) {
            assertResult = assertResult + "TEST FAILED :: gender - field is null\n";
            testCounter++;
        }else if (gender.equals("")) {
            assertResult = assertResult + "TEST FAILED :: gender - field is empty\n";
            testCounter++;
        } else if(!gender.matches("[M|F]")) {
            assertResult = assertResult + "TEST FAILED :: gender - Invalid value, musst be either M or F\n";
            testCounter++;
        }
    }

    private void assertPassword(String password) {
        if (password == null) {
            assertResult = assertResult + "TEST FAILED :: password - field is null\n";
            testCounter++;
        }else if (password.equals("")) {
            assertResult = assertResult + "TEST FAILED :: password - field is empty\n";
            testCounter++;
        }
    }
}
