package za.co.quirk.distell.ccms.bean;

import za.co.quirk.distell.ccms.enums.EntityState;
import za.co.quirk.distell.ccms.enums.PageType;

import java.util.Date;
import java.util.Map;

public class Page implements Comparable {

    private String guid;
    private String title;
    private String keywords;
    private String description;
    private String excerpt;
    private boolean commentingAllowed = false;
    private boolean ratingAllowed = false;
    private EntityState state;
    private PageType type;
    private Date created;
    private Date modified;
    private String tags;
    private Float ratingTotal;
    private Float ratingAverage;
    private Map copyboxes;
    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getExcerpt() {
        return excerpt;
    }

    public void setExcerpt(String excerpt) {
        this.excerpt = excerpt;
    }

    public boolean commentingAllowed() {
        return commentingAllowed;
    }

    public void setCommentingAllowed(boolean commentingAllowed) {
        commentingAllowed = commentingAllowed;
    }

    public boolean ratingAllowed() {
        return ratingAllowed;
    }

    public void setRatingAllowed(boolean ratingAllowed) {
        ratingAllowed = ratingAllowed;
    }

    public EntityState getState() {
        return state;
    }

    public void setState(EntityState state) {
        this.state = state;
    }

    public PageType getType() {
        return type;
    }

    public void setType(PageType type) {
        this.type = type;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public Float getRatingTotal() {
        return ratingTotal;
    }

    public void setRatingTotal(Float ratingTotal) {
        this.ratingTotal = ratingTotal;
    }

    public Float getRatingAverage() {
        return ratingAverage;
    }

    public void setRatingAverage(Float ratingAverage) {
        this.ratingAverage = ratingAverage;
    }

    public Map getCopyboxes() {
        return copyboxes;
    }

    public void setCopyboxes(Map copyboxes) {
        this.copyboxes = copyboxes;
    }

    @Override
    public int compareTo(Object o) {
        Page pageToCompare = (Page) o;
        return pageToCompare.getCreated().after(getCreated()) ? 1 : -1;
    }
}
