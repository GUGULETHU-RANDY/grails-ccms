package za.co.quirk.distell.ccms.enums;

public enum EntityState
{
  PUBLISHED, UNPUBLISHED, ARCHIVED;

  public static EntityState fromString( String s )
  {
    for( EntityState state : EntityState.values() )
    {
      if( ( state.name().toString().substring(0,1).toUpperCase() + state.name().toString().substring(1).toLowerCase() ).equals( s ) )
      {
        return state;
      }
    }
    return null;
  }
}
