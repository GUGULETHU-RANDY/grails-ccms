package za.co.quirk.distell.ccms.service;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.bean.BrandProduct;
import za.co.quirk.distell.ccms.util.CCMSUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CCMSBrandProductService extends DistellRestService {
    public CCMSBrandProductService(String consumerKey, String consumerSecret, boolean staging) {
        super(consumerKey, consumerSecret, staging);
    }

    public List<BrandProduct> getBrandProductsFromCCMS() {
        return getBrandProductsFromCCMS(null);
    }

    public List<BrandProduct> getBrandProductsFromCCMS(Map arguments) {

        List<BrandProduct> products = new ArrayList<BrandProduct>();

        String response = makeCcmsCall("brandproduct", null, arguments);
        if ("error".equals(response)) return products;

        try {
            JSONObject json = new JSONObject(response);
            JSONArray result = json.getJSONArray("result");
            for (int i = 0; i < result.length(); i++) {
                JSONObject productJson = result.getJSONObject(i);
                BrandProduct product = CCMSUtils.createBrandProductFromJson(productJson);
                products.add(product);
            }
        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: " + e);
        }

        return products;
    }

    public BrandProduct getBrandProductFromCCMS(String guid) {

        String response = makeCcmsCall("brandproduct", guid, null, false);
        if ("error".equals(response)) return null;

        try {
            JSONObject json = new JSONObject(response);
            JSONArray productJson = json.getJSONArray("result");
            return CCMSUtils.createBrandProductFromJson(productJson.getJSONObject(0));

        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: " + e);
        }

        return null;
    }
}

