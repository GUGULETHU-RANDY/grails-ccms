package za.co.quirk.distell.ccms.util;

import java.util.*;

public class AgeChecker
{
  private static final double MILLISECONDS_IN_YEAR = 1000 * 60 * 60 * 24 * 365.25;
  public static final String RESULT_UNDER_AGE = "underage";
  protected int LEGIT_AGE;
  private Integer dobDay;
  private Integer dobMonth;
  private Integer dobYear;
  
  private boolean zeroIndex = false;
  private boolean legit = false;
  private boolean remember = true;
  
  public AgeChecker()
  {
    LEGIT_AGE = 18;
  }
  
  public AgeChecker( int age )
  {
    LEGIT_AGE = age;
  }
  
  public Date getDob()
  {
    if( validDob() )
    {
      Calendar dob = Calendar.getInstance( TimeZone.getTimeZone( "GMT+2" ) );
      
      dob.set( Calendar.DAY_OF_MONTH, dobDay );
      dob.set( Calendar.MONTH, dobMonth );
      dob.set( Calendar.YEAR, dobYear );
      
      return dob.getTime();
    }
    
    return null;
  }
  
  public boolean validDob()
  {
    if( dobDay == null || dobMonth == null || dobYear == null )
    {
      return false;
    }
    
    if( dobDay == 0 || dobMonth < 0 || dobYear < 1920 )
    {
      return false;
    }
    
    try
    {
      Calendar calendar = Calendar.getInstance();
      calendar.set( Calendar.YEAR, dobYear );
      calendar.set( Calendar.MONTH, dobMonth );
      
      if( dobDay > calendar.getActualMaximum( Calendar.DATE ) )
      {
        return false;
      }
    }
    catch( RuntimeException e )
    {
      return false;
    }
    
    return true;
  }
  
  public boolean isOlderThanOrEqualAge( Date dateOfBirth )
  {
    if( dateOfBirth != null )
    {
      long diff = DateUtils.getStartOfDay( DateUtils.getCurrentDate() ).getTime() - DateUtils.getStartOfDay( dateOfBirth ).getTime();

      if( (int)( diff / MILLISECONDS_IN_YEAR ) >= LEGIT_AGE )
      {
        return true;
      }
    }

    return false;
  }
  
  public boolean isOlderThanOrEqualAge( Date dateOfBirth, Integer age )
  {
    if( dateOfBirth != null )
    {
      long diff = DateUtils.getStartOfDay( DateUtils.getCurrentDate() ).getTime() - DateUtils.getStartOfDay( dateOfBirth ).getTime();

      if( (int)( diff / MILLISECONDS_IN_YEAR ) >= age )
      {
        return true;
      }
    }

    return false;
  }
  
  public static List getDays()
  {
    List days = new ArrayList();
    
    for( int i = 1; i < 32; i++ )
    {
      days.add( i );
    }
    
    return days;
  }
  
  public static List getMonths()
  {
    List months = new ArrayList();
    
    months.add( new Object[]{ "0", "January" } );
    months.add( new Object[]{ "1", "February" } );
    months.add( new Object[]{ "2", "March" } );
    months.add( new Object[]{ "3", "April" } );
    months.add( new Object[]{ "4", "May" } );
    months.add( new Object[]{ "5", "June" } );
    months.add( new Object[]{ "6", "July" } );
    months.add( new Object[]{ "7", "August" } );
    months.add( new Object[]{ "8", "September" } );
    months.add( new Object[]{ "9", "October" } );
    months.add( new Object[]{ "10", "November" } );
    months.add( new Object[]{ "11", "December" } );
    
    return months;
  }

  public static List getYears()
  {
    List years = new ArrayList();
    for( int i = 1920; i <= DateUtils.getCurrentCalendar().get( Calendar.YEAR ); i++ )
    {
      years.add( i );
    }
    
    return years;
  }

  public Integer getDobDay()
  {
    return dobDay;
  }

  public void setDobDay( Integer dobDay )
  {
    if( dobDay != null )
    {
      if( dobDay < 0 || dobDay > 31 )
      {
        this.dobDay = null;
      }
      else
      {
        this.dobDay = dobDay;
      }
    }
  }

  public Integer getDobMonth()
  {
    if( zeroIndex == false && dobMonth != null )
    {
      return dobMonth + 1;
    }
    
    return dobMonth;
  }

  public void setDobMonth( Integer dobMonth )
  {
    if( dobMonth != null )
    {
      if( dobMonth < 0 || dobMonth > 12 )
      {
        this.dobMonth = null;
      }
      else
      {
        this.dobMonth = dobMonth;
        
        if( zeroIndex == false )
        {
          this.dobMonth = this.dobMonth - 1;
        }
      }
    }
  }

  public Integer getDobYear()
  {
    return dobYear;
  }

  public void setDobYear( Integer dobYear )
  {
    this.dobYear = dobYear;    
  }

  public void setDobYY( Integer dobYY )
  { 
    if( dobYY != null )
    {
      Calendar cal =  DateUtils.getCurrentCalendar();
      String currentYear = String.valueOf( cal.get(  Calendar.YEAR ) );
      Integer currentYY = Integer.parseInt( currentYear.substring( 2 ) );
      Integer currentCC = ( Integer.parseInt( currentYear.substring( 0, 2 ) ) * 100 );

      if( dobYY <= currentYY )
      {
        dobYY = dobYY + currentCC;
      }
      else
      {
        dobYY = dobYY + currentCC - 100;
      } 

      setDobYear( dobYY );
    }
  }
  
  public boolean isZeroIndex()
  {
    return zeroIndex;
  }

  public void setZeroIndex( boolean zeroIndex )
  {
    this.zeroIndex = zeroIndex;
  }

  public boolean isLegit()
  {
    return legit;
  }

  public void setLegit( boolean legit )
  {
    this.legit = legit;
  }

  public boolean isRemember()
  {
    return remember;
  }

  public void setRemember( boolean remember )
  {
    this.remember = remember;
  }
  
}
