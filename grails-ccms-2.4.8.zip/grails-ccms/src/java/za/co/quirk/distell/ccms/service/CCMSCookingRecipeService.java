package za.co.quirk.distell.ccms.service;

import net.oauth.client.OAuthResponseMessage;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.bean.DistellResponse;
import za.co.quirk.distell.ccms.util.RestUtils;
import za.co.quirk.distell.ccms.bean.CookingRecipe;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CCMSCookingRecipeService extends DistellRestService {

    public CCMSCookingRecipeService(String consumerKey, String consumerSecret, boolean staging) {
        super(consumerKey, consumerSecret, staging);
    }

    public List<CookingRecipe> getRecipesFromCCMS() {
        return getRecipesFromCCMS(null);
    }

    public List<CookingRecipe> getRecipesFromCCMS(Map arguments) {

        List<CookingRecipe> cookingRecipes = new ArrayList<CookingRecipe>();

        String response = makeCcmsCall("cooking", null, arguments);
        if ("error".equals(response)) return cookingRecipes;

        try {
            JSONObject json = new JSONObject(response);
            JSONArray result = json.getJSONArray("result");
            for (int i = 0; i < result.length(); i++) {
                JSONObject recipeJson = result.getJSONObject(i);
                CookingRecipe cookingRecipe = CookingRecipe.fromJson(recipeJson);
                cookingRecipes.add(cookingRecipe);
            }
        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: " + e);
        }

        return cookingRecipes;
    }

    public CookingRecipe getRecipeFromCCMS(String guid) {

        String response = makeCcmsCall("cooking", guid, null, false);
        if ("error".equals(response)) return null;

        try {
            JSONObject json = new JSONObject(response);

            JSONObject recipeJson = json.getJSONObject("result");
            return  CookingRecipe.fromJson(recipeJson);

        } catch (JSONException e) {
            log.error("Error parsing json from CCMS response: " + e);
        }

        return null;
    }

    public Boolean saveToCCMS(CookingRecipe cookingRecipe) {

        JSONObject json = cookingRecipe.toJson();

        OAuthResponseMessage response;

        try {
            response = post(json.toString().getBytes("UTF-8"), "cooking");
        } catch (Exception e) {
            log.error("Failed to comms to Distell server", e);

            return false;
        }

        DistellResponse distellResponse = RestUtils.decipherResponse(response);

        if (distellResponse.getError() != null) {

            log.error("CCMS returned a fail response on cooking recipe submission - error: " + distellResponse.getError());
            log.error("CCMS result: " + distellResponse.getResult());

            return false;
        }

        return true;
    }
}
