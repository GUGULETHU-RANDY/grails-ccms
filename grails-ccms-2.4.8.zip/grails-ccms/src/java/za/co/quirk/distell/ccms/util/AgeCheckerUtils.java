package za.co.quirk.distell.ccms.util;

import org.joda.time.DateTime;

import java.util.Calendar;
import java.util.Date;

public class AgeCheckerUtils {
    public static Date getDateFromYMD(String year, String month, String day) {
        DateTime dt = getDateTimeFromYMD(year, month, day);

        if(dt != null) {
            return dt.toDate();
        }

        return null;
    }

    public static DateTime getDateTimeFromYMD(String year, String month, String day) {
        year = convert4DigitYear(year);

        try {
            DateTime dt = new DateTime(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day), 0, 0);
            return dt;
        }
        catch (Exception e) {
            return null;
        }
    }

    public static String convert4DigitYear(String yearString) {
        if(yearString == null) return null;

        try {
            Integer year = Integer.valueOf(yearString);
            if (year < 100) {
                if (year > (Calendar.getInstance().get(Calendar.YEAR) - 2000)) {
                    year += 1900;
                }
                else {
                    year += 2000;
                }

                return year.toString();
            }
            else {
                return yearString;
            }
        }
        catch (NumberFormatException e) {
            return yearString;
        }
    }
}

