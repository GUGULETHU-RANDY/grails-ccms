/**
 * 07 Oct 2011
 */
package za.co.quirk.distell.ccms.service;

import net.oauth.*;
import net.oauth.client.OAuthClient;
import net.oauth.client.OAuthResponseMessage;
import net.oauth.client.httpclient4.HttpClient4;
import net.oauth.http.HttpClient;
import net.oauth.http.HttpMessage;
import net.oauth.http.HttpMessageDecoder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class DistellRestService {
    public static final Log log = LogFactory.getLog(DistellRestService.class);
    private static final String CCMS_LIVE_URL = "https://ccms.distell.co.za/api/";
    private static final String CCMS_STAGING_URL = "http://staging.ccms.liquorice.co.za/api/";
    protected static final int CCMS_CONNECT_TIMEOUT = 30000;
    protected static final int CCMS_READ_TIMEOUT = 35000;
    private boolean validate = true;
    private boolean staging = false;
    private String consumerKey;
    private String consumerSecret;
    public DistellRestService(String consumerKey, String consumerSecret) {
        this.consumerKey = consumerKey;
        this.consumerSecret = consumerSecret;
    }

    public DistellRestService(String consumerKey, String consumerSecret, boolean staging) {
        this.consumerKey = consumerKey;
        this.consumerSecret = consumerSecret;
        this.staging = staging;
    }

    public DistellRestService() {
    }

    protected OAuthResponseMessage post(byte[] body, String section) throws OAuthException, IOException, URISyntaxException {

        String url = staging ? CCMS_STAGING_URL : CCMS_LIVE_URL;
        url += section;

        OAuthConsumer oAuthConsumer = new OAuthConsumer(null, getConsumerKey(), getConsumerSecret(), new OAuthServiceProvider(null,
                null, null));

        OAuthAccessor accessor = new OAuthAccessor(oAuthConsumer);

        OAuthClient client = new OAuthClient(new HttpClient4());

        client.getHttpParameters().put(client.getHttpClient().CONNECT_TIMEOUT, CCMS_CONNECT_TIMEOUT);
        client.getHttpParameters().put(client.getHttpClient().READ_TIMEOUT, CCMS_READ_TIMEOUT);

        OAuthResponseMessage response;

        OAuthMessage request = new OAuthMessageWithBody(HttpClient.POST, url, null, "text/xml; charset=\"UTF-8\"", body);
        request.addRequiredParameters(accessor);

        try {
            response = (OAuthResponseMessage) client.invoke(request, ParameterStyle.AUTHORIZATION_HEADER);
        } catch (Exception e) {
            log.error("Exception casting response from CCMS - call failed: ", e);
            return null;
        }

        return response;
    }

    protected String makeCcmsCall(String area, String guid, Map arguments) {
        return makeCcmsCall(area, guid, arguments, true);
    }

    protected String makeCcmsCall(String area, String guid, Map arguments, boolean logOnSubmissionError) {
        String ccmsUrl = staging ? CCMS_STAGING_URL : CCMS_LIVE_URL;

        String args = area.equals("media") ? "limit=500" : "limit=200";

        if (arguments != null && !arguments.isEmpty()) {
            for (Object entry : arguments.entrySet()) {
                Entry<String, String> entry2 = (Entry<String, String>) entry;
                try {
                    args += "&" + entry2.getKey() + "=" + URLEncoder.encode(entry2.getValue(), "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    log.error("Failed to encode CCMS call parameter as url", e);
                }
            }
        }

        String ret = "error";

        OAuthConsumer consumer = new OAuthConsumer(null, consumerKey, consumerSecret, new OAuthServiceProvider(null,
                null, null));

        if (staging) {
            log.info("Using key: " + consumerKey + " and secret: " + consumerSecret);
        }

        OAuthAccessor accessor = new OAuthAccessor(consumer);
        accessor.setProperty("oauth_signature_method", "HMAC-SHA1");

        OAuthClient client = new OAuthClient(new HttpClient4());

        client.getHttpParameters().put(client.getHttpClient().CONNECT_TIMEOUT, CCMS_CONNECT_TIMEOUT);
        client.getHttpParameters().put(client.getHttpClient().READ_TIMEOUT, CCMS_READ_TIMEOUT);

        OAuthResponseMessage response = null;

        String guidParameterName = ("page".equals(area)) ? "uri" : "guid";//CCMS calls guid different things for different sections
        String callUrl = guid != null ? ccmsUrl + area + "?" + guidParameterName + "=" + guid + "&" + args : ccmsUrl + area + "?" + args;

        try {
            OAuthMessage request = new OAuthMessageWithBody(HttpClient.GET, callUrl, null, null,
                    null);
            request.addRequiredParameters(accessor);

            response = (OAuthResponseMessage) client.invoke(request, ParameterStyle.AUTHORIZATION_HEADER);

            ret = response.readBodyAsString();
            if (staging) {
                log.info("Response from CCMS: " + ret);
            }
        } catch (Exception e) {
            if (logOnSubmissionError) {
                log.error("Failed to comms to Distell server: ", e);
            }
        }

        return ret;
    }

    public String getConsumerKey() {
        return consumerKey;
    }
    public void setConsumerKey(String consumerKey) {
        this.consumerKey = consumerKey;
    }
    public String getConsumerSecret() {
        return consumerSecret;
    }
    public void setConsumerSecret(String consumerSecret) {
        this.consumerSecret = consumerSecret;
    }
    public String getEmail() {
        return "";
    }
    public void setEmail(String email) {
    }
    public boolean getValidate() {
        return validate;
    }
    public void setValidate(boolean validate) {
        this.validate = validate;
    }
    public boolean getStaging() {
        return staging;
    }

    public void setStaging(boolean staging) {
        this.staging = staging;
    }
    private class OAuthMessageWithBody extends OAuthMessage {
        private final byte[] body;

        public OAuthMessageWithBody(String method, String URL, List<Entry<String, String>> parameters,
                                    String contentType, byte[] body) {

            super(method, URL, parameters);
            this.body = body;
            List<Entry<String, String>> headers = getHeaders();
            headers.add(new OAuth.Parameter(HttpMessage.ACCEPT_ENCODING, HttpMessageDecoder.ACCEPTED));
            if (body != null) {
                headers.add(new OAuth.Parameter(HttpMessage.CONTENT_LENGTH, String.valueOf(body.length)));
            }
            if (contentType != null) {
                headers.add(new OAuth.Parameter(HttpMessage.CONTENT_TYPE, contentType));
            }
        }

        public InputStream getBodyAsStream() {
            return (body == null) ? null : new ByteArrayInputStream(body);
        }
    }
}
