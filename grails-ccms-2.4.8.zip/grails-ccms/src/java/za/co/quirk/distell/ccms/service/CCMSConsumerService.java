package za.co.quirk.distell.ccms.service;

import net.oauth.client.OAuthResponseMessage;
import org.json.JSONException;
import org.json.JSONObject;
import za.co.quirk.distell.ccms.bean.DistellCCMSConsumer;
import za.co.quirk.distell.ccms.bean.DistellResponse;
import za.co.quirk.distell.ccms.util.CCMSUtils;
import za.co.quirk.distell.ccms.util.RestUtils;
import za.co.quirk.distell.ccms.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

public class CCMSConsumerService extends DistellRestService {

    private boolean useConsumerIdHack = true;
    public CCMSConsumerService(String consumerKey, String consumerSecret, boolean staging) {
        super(consumerKey, consumerSecret, staging);
    }
    public boolean getUseConsumerIdHack() {
        return useConsumerIdHack;
    }
    public void setUseConsumerIdHack(boolean useConsumerIdHack) {
        this.useConsumerIdHack = useConsumerIdHack;
    }

    public String sendEmail(String ccmsSession, String subject, String templateGUID, Map<String, String>params) {

        JSONObject json = new JSONObject();
        try {
            json.put("session_id", ccmsSession);
            json.put("subject", subject);
            json.put("templateUri", templateGUID);
            json.put("additionalTemplateTags", params);

        } catch (JSONException ex) {
            log.error("Exception constructing JSON object for send email request", ex);

            return null;
        }

        OAuthResponseMessage response;

        try {
            response = post(json.toString().getBytes("UTF-8"), "email");
        } catch (Exception e) {
            log.error("Send email request POST to CCMS failed", e);

            return null;
        }

        DistellResponse distellResponse = RestUtils.decipherResponse(response);

        if (distellResponse.getError() != null) {
            log.error("CCMS returned a fail response when trying to send an email");
            log.error("CCMS error: " + distellResponse.getError());

            return null;
        } else {
            return "success";
        }
    }

    public String sendSms(String ccmsSession, String templateUri, Map additionalTemplateTags) {

        JSONObject json = new JSONObject();

        try {
            json.put("session_id", ccmsSession);
            json.put("templateUri", templateUri);
            if(additionalTemplateTags != null) {
                json.put("additionalTemplateTags", additionalTemplateTags);
            }

        } catch (JSONException ex) {
            log.error("Exception constructing JSON object for send sms request", ex);

            return null;
        }

        OAuthResponseMessage response;

        try {
            response = post(json.toString().getBytes("UTF-8"), "sms");
        } catch (Exception e) {
            log.error("Send sms request POST to CCMS failed", e);

            return null;
        }

        DistellResponse distellResponse = RestUtils.decipherResponse(response);

        if (distellResponse.getError() != null) {
            log.error("CCMS returned a fail response when trying to send an sms");
            log.error("CCMS error: " + distellResponse.getError());

            return null;
        } else {
            return "success";
        }
    }

    public String sendSms(String ccmsSession, String templateUri) {
        return sendSms(ccmsSession, templateUri, null);
    }

    public Map submitConsumer(DistellCCMSConsumer consumer) {
        HashMap<String, Object> result = new HashMap<String, Object>();

        if (getValidate()) {
            Map errors = consumer.validate();
            if (errors.keySet().size() > 0) {
                log.error("CCMS customer failed validation before send");
                for (Object i : errors.keySet()) {
                    log.error("Validation error: " + i + " : " + errors.get(i));
                }
                result.put("qccmsResult", new String("There was a problem with the data submitted, please check the consumer information"));
                result.put("consumer", consumer);
                result.put("distellResponse", null);
                return result;
            }
        }

        DistellCCMSConsumer retrievedConsumer;
        if(!StringUtils.isEmpty(consumer.getEmailAddress())){
            retrievedConsumer = getConsumerDetails(consumer.getEmailAddress());
        } else {
            retrievedConsumer = getConsumerDetails(consumer.getContactNumber());
        }

        if (retrievedConsumer != null) {
            consumer.setId(retrievedConsumer.getId());
        }

        DistellResponse response = sendToCCMS(consumer);
        result.put("distellResponse", response);
        result.put("consumer", consumer);

        if (response != null && response.isSuccessful()) {
            result.put("qccmsResult", RestUtils.isSuccessfulResult(response));
        } else {
            result.put("qccmsResult", new String("There was an error submitting your information. Please try again later"));
        }

        return result;
    }

    public Map submitConsumer(String consumerJSONString) {
        JSONObject consumerJSON;
        HashMap<String, Object> result = new HashMap<String, Object>();

        try {
            consumerJSON = new JSONObject(consumerJSONString);
        } catch (JSONException e) {
            result.put("qccmsResult", new String("error: Invalid json submitted"));
            result.put("consumer", consumerJSONString);
            result.put("distellResponse", null);
            return result;
        }

        DistellCCMSConsumer consumer = CCMSUtils.createConsumerFromJson(consumerJSON);

        return submitConsumer(consumer);
    }

    public Map submitConsumer(JSONObject consumerJSON) {

        DistellCCMSConsumer consumer = CCMSUtils.createConsumerFromJson(consumerJSON);

        return submitConsumer(consumer);
    }


    @Deprecated
    public String send(DistellCCMSConsumer consumer) {
        if (getValidate()) {
            Map errors = consumer.validate();
            if (errors.keySet().size() > 0) {
                log.error("CCMS customer failed validation before send");
                for (Object i : errors.keySet()) {
                    log.error("Validation error: " + i + " : " + errors.get(i));
                }
                return "There was a problem with the data submitted, please check the consumer information";
            }
        }

        DistellCCMSConsumer retrievedConsumer;
        if(!StringUtils.isEmpty(consumer.getEmailAddress())){
            retrievedConsumer = getConsumerDetails(consumer.getEmailAddress());
        } else {
            retrievedConsumer = getConsumerDetails(consumer.getContactNumber());
        }

        if (retrievedConsumer != null) {
            consumer.setId(retrievedConsumer.getId());
        }

        DistellResponse response = sendToCCMS(consumer);

        if (response != null && response.isSuccessful()) {
            return RestUtils.isSuccessfulResult(response);
        } else {
            return "There was an error submitting your information. Please try again later";
        }
    }

    @Deprecated
    public String send(String consumerJSONString) {

        JSONObject consumerJSON;

        try {
            consumerJSON = new JSONObject(consumerJSONString);
        } catch (JSONException e) {
            return "error: Invalid json submitted";
        }

        DistellCCMSConsumer consumer = CCMSUtils.createConsumerFromJson(consumerJSON);

        return send(consumer);
    }

    @Deprecated
    public String send(JSONObject consumerJSON) {

        DistellCCMSConsumer consumer = CCMSUtils.createConsumerFromJson(consumerJSON);

        return send(consumer);
    }

    private DistellResponse sendToCCMS(DistellCCMSConsumer consumer) {

        JSONObject json = consumer.toJson(false);

        if (useConsumerIdHack) {
            try {
                Long id = json.getLong("id");
                if (id != null && id != 0) {
                    json.put("consumer_id", id);
                    json.remove("id");
                }
            } catch (JSONException e) {
            }
        }

        OAuthResponseMessage response;

        try {
            response = post(json.toString().getBytes("UTF-8"), "consumer");
        } catch (Exception e) {
            log.error("Failed to comms to Distell server : [" + consumer.getEmailAddress() + " | " + consumer.getSource() + "]", e);

            return null;
        }

        DistellResponse distellResponse = RestUtils.decipherResponse(response);

        if (!distellResponse.isSuccessful()) {

            log.error("Result: " + distellResponse.getResult());
            log.error("CCMS returned a fail response on consumer submission (see result above)");

            return null;
        }

        return distellResponse;
    }

    public DistellCCMSConsumer getConsumerDetails(String identifier) {

        Map args = new HashMap();
        String identityField = "email_uri";
        if(!StringUtils.validateEmailAddress(identifier)){
            identityField = "mobile";
        }

        args.put(identityField, identifier);

        String response = makeCcmsCall("consumer", null, args, false);
        if ("error".equals(response)) return null;

        try {
            JSONObject json = new JSONObject(response);
            JSONObject consumerJson = json.getJSONObject("result");

            return DistellCCMSConsumer.fromJson(consumerJson);
        } catch (Exception e) {
        }

        return null;
    }

    public String loginConsumer(String identifier, String password) {
        JSONObject json = new JSONObject();

        String identityField = "email";
        if(!StringUtils.validateEmailAddress(identifier)){
            identityField = "mobile";
        }
        try {
            json.put(identityField, identifier);
            json.put("password", password);
        } catch (Exception e) {
            log.error("Error constructing JSON for consumer reset, identifier: " + identityField);

            return null;
        }

        OAuthResponseMessage response;

        try {
            response = post(json.toString().getBytes("UTF-8"), "login");
        } catch (Exception e) {
            log.error("Failed to comms to Distell server : [" + json.toString() + "]", e);

            return null;
        }

        DistellResponse distellResponse = RestUtils.decipherResponse(response);

        if (distellResponse != null && distellResponse.isSuccessful()) {
            try {
                JSONObject jsonResponse = new JSONObject(distellResponse.getResult());

                return jsonResponse.getString("session_id");

            } catch (JSONException e) {
                log.error("Error retrieving session id from Distell response", e);
            }
        }

        return null;
    }

    public String resetConsumerPassword(String identifier) {
        JSONObject json = new JSONObject();
        String identityField = "email";
        if(!StringUtils.validateEmailAddress(identifier)){
            identityField = "mobile";
        }

        try {
            json.put(identityField, identifier);
        } catch (Exception e) {
            log.error("Error constructing JSON for consumer reset, " + identityField + ": " + identifier);
        }

        OAuthResponseMessage response;

        try {
            response = post(json.toString().getBytes("UTF-8"), "passwordreset");
        } catch (Exception e) {
            log.error("Failed to comms to Distell server : [" + json.toString() + "]", e);

            return null;
        }

        DistellResponse distellResponse = RestUtils.decipherResponse(response);

        if (distellResponse != null && distellResponse.isSuccessful()) {
            try {
                JSONObject jsonResponse = new JSONObject(distellResponse.getResult());

                return jsonResponse.getString("password");

            } catch (JSONException e) {
                log.error("Error retrieving password from Distell response", e);
            }
        }

        return null;
    }
}
