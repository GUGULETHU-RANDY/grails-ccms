package za.co.quirk.distell.ccms.bean;

import java.util.Date;

public class MediaItem {

    String guid;

    String name;
    String gallery;
    String description;
    String mimeSupertype;
    String mimeSubtype;
    int redemptionPoints = 0;
    String altText;
    String externalUrl;
    boolean thumbnail = false;
    String tags;
    String imageUrl;
    String fileUrl;
    String thumbnail128Url;
    Date created;
    Date modified;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGallery() {
        return gallery;
    }

    public void setGallery(String gallery) {
        this.gallery = gallery;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMimeSupertype() {
        return mimeSupertype;
    }

    public void setMimeSupertype(String mimeSupertype) {
        this.mimeSupertype = mimeSupertype;
    }

    public String getMimeSubtype() {
        return mimeSubtype;
    }

    public void setMimeSubtype(String mimeSubtype) {
        this.mimeSubtype = mimeSubtype;
    }

    public int getRedemptionPoints() {
        return redemptionPoints;
    }

    public void setRedemptionPoints(int redemptionPoints) {
        this.redemptionPoints = redemptionPoints;
    }

    public String getAltText() {
        return altText;
    }

    public void setAltText(String altText) {
        this.altText = altText;
    }

    public String getExternalUrl() {
        return externalUrl;
    }

    public void setExternalUrl(String externalUrl) {
        this.externalUrl = externalUrl;
    }

    public boolean getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(boolean thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getThumbnailUrl() {
        return thumbnail128Url;
    }

    public void setThumbnail128Url(String thumbnail128Url) {
        this.thumbnail128Url = thumbnail128Url;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }
}
