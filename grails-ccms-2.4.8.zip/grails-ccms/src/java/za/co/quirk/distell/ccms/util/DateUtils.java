
package za.co.quirk.distell.ccms.util;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DateUtils
{
  public static Date getCurrentDate()
  {
    return getCurrentCalendar().getTime();
  }
  
  public static Calendar getCurrentCalendar()
  {
    return Calendar.getInstance( TimeZone.getTimeZone( "GMT+2" ) );
  }
  
  public static Date getStartOfDay( Date startDate )
  {
    Calendar cal = getCurrentCalendar();
    cal.setTime( startDate );
    cal.set( Calendar.HOUR, 0 );
    cal.set( Calendar.MINUTE, 0 );
    cal.set( Calendar.SECOND, 0 );
    
    return cal.getTime();
  }
}
