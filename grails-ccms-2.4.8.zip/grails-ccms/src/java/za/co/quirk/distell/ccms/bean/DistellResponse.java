/**
 * 07 Oct 2011
 */
package za.co.quirk.distell.ccms.bean;


public class DistellResponse
{
    private int statusCode;
    private Boolean successful;
    private String timeStamp;
    private String result;
    private String error;
    public Boolean isSuccessful() {
        return successful;
    }
    public void setSuccess(Boolean success) {
        this.successful = success;
    }
    public String getTimeStamp() {
        return timeStamp;
    }
    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }
    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }
    public String getError() {
        return error;
    }
    public void setError(String error) {
        this.error = error;
    }
    public int getStatusCode() {
        return statusCode;
    }
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }
    
    @Override
    public String toString() {
        
        String string = "Status Code=" + statusCode + " | " + "Successful=" + successful + " | " +  "Error=" + error + " | " + "Result=" + result;

        return string;
        
    }

}
