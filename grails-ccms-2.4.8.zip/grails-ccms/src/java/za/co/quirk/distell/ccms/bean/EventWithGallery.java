package za.co.quirk.distell.ccms.bean;

import java.util.List;


public class EventWithGallery extends Event {

    private List<MediaItem> gallery;

    public List<MediaItem> getGallery() {
        return gallery;
    }

    public void setGallery(List<MediaItem> gallery) {
        this.gallery = gallery;
    }
}
