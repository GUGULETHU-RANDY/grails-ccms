package za.co.quirk.distel.ccms.grailsservice

import org.codehaus.groovy.grails.web.json.JSONObject
import za.co.quirk.distel.ccms.Utilities

class FacebookService {

    static transactional = false

    def grailsApplication

    Map loadAccessTokenFromFb(String code) {
        String url = getOAuthUrlStep2(code)

        try {
            return Utilities.parseResponse(new URL(url).getText())
        }
        catch (Exception e) {
            FacebookService.log.error("error loading facebook access token:" + e)
        }

        return null
    }

    JSONObject loadUserFromFb(session) {
        loadUserFromFb(session, null)
    }

    JSONObject loadUserFromFb(session, fields) {
        String url = getUserUrl(session, fields)

        try {
            return new JSONObject(new URL(url).getText())
        }
        catch (Exception e) {
            FacebookService.log.error("error loading facebook user:" + e)
        }

        return null
    }

    JSONObject loadUserAgeRange(session) {
        String url = getUserUrl(session, "age_range")

        try {
            return new JSONObject(new URL(url).getText())
        }
        catch (Exception e) {
            FacebookService.log.error "error loading facebook user: " + e
        }

        return null
    }

    String getOAuthUrlStep1() {
        String appId = grailsApplication.config.facebook.app.id
        String redirectUri = grailsApplication.config.facebook.app.redirectUri
        String scope = grailsApplication.config.facebook.app.scope

        return "https://www.facebook.com/dialog/oauth?client_id=${appId}&redirect_uri=${redirectUri}&scope=${scope}"
    }

    String getOAuthUrlStep2(String code) {
        String appId = grailsApplication.config.facebook.app.id
        String appSecret = grailsApplication.config.facebook.app.secret
        String redirectUri = grailsApplication.config.facebook.app.redirectUri

        return "https://graph.facebook.com/oauth/access_token?client_id=${appId}&redirect_uri=${redirectUri}" +
                "&client_secret=${appSecret}&code=${code}&method=GET"
    }

    Boolean isLoggedIn(session) {
        return session.accessToken ? true : false
    }

    String getLoggedInUserId(def session) {
        return isLoggedIn(session) ? session.fbUserId : null
    }

    Boolean login(session, Map loginResponse) {
        session.accessToken = loginResponse['access_token']
        session.expires = loginResponse['expires']
        try {
            if (loginResponse['expires']) {
                session.expires = loginResponse['expires']
            }
        } catch (Exception e) {
        }

        if (session.accessToken) {
            JSONObject user = new JSONObject(loadObject("user", null, null, null, session))
            session.fbUserId = user.id

            return true
        }

        return false
    }

    void logout(session) {
        session.remove('accessToken')
        session.remove('expires')
    }

    private String getUserUrl(session) {
        getUserUrl(session, null)
    }
    private String getUserUrl(session, String fields) {
        if (!isLoggedIn(session)) return ''

        String url = "https://graph.facebook.com/me?access_token=${session.accessToken}"

        if (fields) url += "&fields=${fields}"

        return url
    }

    private String buildUrl(String object, String id, String fields, String method, session) {
        String url = ''

        if (!isLoggedIn(session)) return url

        url = 'https://graph.facebook.com/'

        if (id) {
            url += id
        } else if (object && object.equalsIgnoreCase("user")) {
            url += "me"
        } else {
            return url
        }

        url = Utilities.appendParams(url, 'fields', fields)
        url = Utilities.appendParams(url, 'method', method ?: 'GET')
        url = Utilities.appendParams(url, 'access_token', session.accessToken)

        return url
    }

    private String loadObject(String obj, String id, String fields, String method, session) {
        String url = buildUrl(obj, id, fields, method, session)

        try {
            return new URL(url).getText()
        }
        catch (Exception e) {
            FacebookService.log.error("error retrieving facebook object:" + obj + "with id:" + id + "," + e)
        }

        return null
    }
}

