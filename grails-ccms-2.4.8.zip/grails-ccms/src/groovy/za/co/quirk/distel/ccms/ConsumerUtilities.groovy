package za.co.quirk.distel.ccms

class ConsumerUtilities {

    static String toCcmsDate(Date date) {
        if(!date) return ''

        return date.format('yyyy') + '-' + toDoubleDigit(date.format('MM')) + '-' + toDoubleDigit(date.format('dd'))
    }

    static String toDoubleDigit(String input) {
        return input?.size() == 1 ? '0' + input : input
    }
}
