package za.co.quirk.distel.ccms

import java.text.ParseException

class Validator {

    static exists = { Object value ->
        return value ? true : false
    }

    static notNull = { Object value ->
        return value != null
    }

    static plainText = { String value ->
        return value?.size() && (value.replaceAll(/[0123456789~#$%\^@&*+=\[\]\\;,\/{}|\\":<>?]/,'') == value)
    }

    static plainTextValidationOnly = { String value ->
        return !value?.size() || (value.replaceAll(/[0123456789~#$%\^@&*+=\[\]\\;,\/{}|\\":<>?]/,'') == value)
    }

    static date = { String value ->
        try {
            Date.parse('dd/MM/yyyy', value)
            return true
        }
        catch (Exception e) {}

        return false
    }

    static number = { String value ->
        return value?.isBigDecimal()
    }

    static numberWithSpaces = { String value ->
        return value?.replace(' ','')?.isBigDecimal()
    }

    static numberValidationOnly = { String value ->
        return !value?.size() || this.number(value)
    }

    static numberWithSpacesValidationOnly = { String value ->
        return !value?.size() || this.numberWithSpaces(value)
    }

    static idNumber = { String value ->
        if (!(value && value.isLong() && value.size() == 13)) return false;

        Integer[] numberArray = new Integer[value.length()];

        for( int i = 0; i < value.length(); i++ )
        {
            String digit = value.substring( i, i + 1 );

            try
            {
                numberArray[i] = new Integer( digit );
            }
            catch( NumberFormatException e )
            {
                return false;
            }
        }

        int lastDigit = numberArray[numberArray.length - 1].intValue();

        int controlDigit;
        try
        {
            int a = 0;
            for( int i = 0; i < 6; i++ )
            {
                a += numberArray[2 * i].intValue();
            }

            int b = 0;
            for( int i = 0; i < 6; i++ )
            {
                b = b * 10 + numberArray[2 * i + 1].intValue();
            }

            b *= 2;

            int c = 0;

            c += b % 10;
            b = b / 10;

            while( b > 0 ) {
                c += b % 10;
                b = b / 10;
            }

            c += a;
            controlDigit = 10 - ( c % 10 );

            if( controlDigit == 10 )
            {
                controlDigit = 0;
            }
        }
        catch( Exception e )
        {
            return false;
        }

        if( controlDigit != lastDigit )
        {
            return false;
        }

        return true;
    }

    static email = { String value ->
        if (!value || !value.size()) return false;

        return value ==~ /[_A-Za-z0-9-]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})/
    }

    static phone = { String value ->
        String cleanNumber = value?.replace(' ', '')?.replace('(', '')?.replace(')', '')?.replace('-', '')?.replace('+', '');

        return ((value?.size() ?: 0) < 21) && cleanNumber && cleanNumber.isLong();
    }

    static phoneValidationOnly = { String value ->
        return !value?.size() || this.phone(value)
    }

    static validDob = { String value ->
        if(!value?.size()) return false

        try {
            new Date().parse('yyyy-MM-dd', value)
            return true
        }
        catch (ParseException e) {
            return false
        }
    }

    static Map validationFunctions = [
            title:exists,
            first_name:exists,
            last_name:exists,
            email:email,
            mobile:phone,
            dob:validDob,
            facebook_id:exists,
            gender:exists,
            twitter_id:exists,
            region:exists,
            id_number:idNumber,
            terms_and_conditions:exists,
            'brandFields.net_promoter_score_${appName}':exists,
            whatAbout:exists,
            'brandFields.contactMessage':exists
    ];
}

