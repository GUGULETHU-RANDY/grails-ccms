package za.co.quirk.distel.ccms

import javax.servlet.http.Cookie

class Utilities {

    private static final int COOKIE_MAX_AGE = 2500000

    static void setCookie(response, cookieName, value) {
        def c = new Cookie(cookieName, value)
        c.path = '/'
        c.maxAge = COOKIE_MAX_AGE
        response.addCookie(c)
    }

    static Boolean checkAgeCookie(request, session, cookieIdentifier, sessionIdentifier) {
        Boolean foundCookie = false
        request.cookies.each {
            if (it.name == cookieIdentifier) {
                foundCookie = true
                session[sessionIdentifier] = Date.parse('yyyy-MM-dd', it.value)
            }
        }

        return foundCookie
    }

    static Boolean checkCountryCookie(request, session, cookieIdentifier, sessionIdentifier) {
        boolean foundCookie = false
        request.cookies.each {
            if (it.name == cookieIdentifier) {
                foundCookie = true
                session[sessionIdentifier] = it.value
            }
        }

        return foundCookie
    }

    static String constructEmailMessageFromParams(params) {
        String message = ''
        params.each { key, value ->
            message += "$key: $value\n"
        }

        return message
    }

    static Boolean checkValidDayAndMonth(String dayString, String monthString) {
        try {
            Integer day = Integer.parseInt(dayString)
            Integer month = Integer.parseInt(monthString)

            if (month < 1 || month > 12 || day < 1 || day > 31) {return false}
            if ([2, 4, 6, 9, 11].contains(month) && day > 30) {return false}
            if (month == 2 && day > 29) {return false}
        }
        catch (NumberFormatException e) {
            return false
        }

        return true
    }

    static String appendParams(String str, String key, String value) {
        if(!str?.size()) return ''

        if(!key?.size() || !value?.size()) return str

        return str + (str.contains("?") ? "&" : "?") + key + "=" + value
    }

    static Map parseResponse(String data) {
        Map map = [:]

        data?.split('&')?.each { String param ->
            String[] nameAndValue = param.split('=')

            if(nameAndValue?.size() == 2) map[nameAndValue[0]] = nameAndValue[1]
        }

        return map
    }
}
