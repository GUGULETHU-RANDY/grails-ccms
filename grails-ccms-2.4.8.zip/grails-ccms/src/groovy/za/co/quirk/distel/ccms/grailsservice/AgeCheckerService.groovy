package za.co.quirk.distel.ccms.grailsservice

import org.joda.time.DateTime
import org.springframework.beans.factory.InitializingBean
import za.co.quirk.distel.ccms.Utilities
import za.co.quirk.distell.ccms.service.CCMSAgeCheckerService
import za.co.quirk.distell.ccms.util.AgeCheckerUtils

class AgeCheckerService implements InitializingBean {

    static transactional = false

    def grailsApplication
    CCMSAgeCheckerService service

    @Override
    public void afterPropertiesSet() {
        service = new CCMSAgeCheckerService(grailsApplication.config.ccms.consumerKey, grailsApplication.config.ccms.consumerSecret, false)
    }

    Boolean isLegit(String dobYear, String dobMonth, String dobDay, String countryCode) throws IllegalArgumentException {
        if (!Utilities.checkValidDayAndMonth(dobDay, dobMonth)) {
            throw new IllegalArgumentException()
        }

        return isLegit(AgeCheckerUtils.getDateFromYMD(dobYear, dobMonth, dobDay), countryCode)
    }

    Boolean isLegit(Integer age, String countryCode) {
        DateTime dob = DateTime.now().minusYears(age)

        return isLegit(dob, countryCode)
    }

    Boolean isLegit(Date birthDate, String countryCode) {
        if (!birthDate) return false

        return isLegit(new DateTime(birthDate), countryCode)
    }

    Boolean isLegit(DateTime birthDate, String countryCode) {
        if (!birthDate) return false

        countryCode = countryCode?.take(2)?.toString()?.toUpperCase() ?: 'ZA'

        if (countryCode.equalsIgnoreCase('ZA')) {
            return performLocalAgeCheck(birthDate)
        }

        try {
            return service.performRemoteAgeCheck(birthDate, countryCode);
        } catch (Exception e) {
            AgeCheckerService.log.error("ageChecker: ccms issue or country code not valid - falling back to local check.", e)
        }

        return performLocalAgeCheck(birthDate)
    }

    private Boolean performLocalAgeCheck(DateTime birthDate) {
        return (getAge(birthDate) >= 18)
    }

    private Integer getAge(DateTime birthDate) {
        if (!birthDate) return 0

        return DateTime.now().getYear() - birthDate.getYear()
    }
}
