package za.co.quirk.distell.ccms

import za.co.quirk.distel.ccms.ConsumerUtilities

class ConsumerUtilitiesTests {
    //toCcmsDate
    void testToCcmsDateShouldReturnEmptyStringForNullDate() {
        assert ConsumerUtilities.toCcmsDate(null) == ''
    }

    void testToCCMSDateShouldAlwaysReturnDoubleDigitDaysAndMonths() {
        assert ConsumerUtilities.toCcmsDate(Date.parse('yyyy-MM-dd', '1999-1-1')) == '1999-01-01'
        assert ConsumerUtilities.toCcmsDate(Date.parse('yyyy-MM-dd', '2014-10-1')) == '2014-10-01'
        assert ConsumerUtilities.toCcmsDate(Date.parse('yyyy-MM-dd', '2014-10-31')) == '2014-10-31'
    }
}
