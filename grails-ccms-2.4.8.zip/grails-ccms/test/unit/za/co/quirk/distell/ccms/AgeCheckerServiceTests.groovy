package za.co.quirk.distell.ccms

import grails.test.mixin.*
import za.co.quirk.distel.ccms.grailsservice.AgeCheckerService

@TestFor(AgeCheckerService)
class AgeCheckerServiceTests {

    //isLegit for dob Strings
    void testShouldFailForStringDOBForEdgeCases() {
        shouldFail(IllegalArgumentException) {
            service.isLegit(null, null, null, null)
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit(null, null, null, 'ZA')
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('1', '1', null, null)
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('2014', '07', null, 'ZA')
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit(null, null, '1', null)
        }
    }

    void testShouldFailForImpossibleDOB() {
        shouldFail(IllegalArgumentException) {
            service.isLegit('1970', '13', '1', null)
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('1970', '13', '1', 'ZA')
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('1970', '1', '32', null)
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('1970', '1', '32', 'ZA')
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('1970', '1', '121', null)
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('1970', '1', '121', 'ZA')
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('1970', '4', '31', null)
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('1970', '4', '31', 'ZA')
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('1970', '2', '30', null)
        }
        shouldFail(IllegalArgumentException) {
            assert !service.isLegit('1970', '2', '30', 'ZA')
        }
    }

    void testShouldFailForStringDOBForUnder18InSouthAfrica() {
        assert !service.isLegit('2014', '1', '1', 'ZA')
        assert !service.isLegit('2014', '01', '1', 'Za')
        assert !service.isLegit('2014', '0001', '1', 'zA')
        assert !service.isLegit('2014', '11', '01', 'za')
        assert !service.isLegit('14', '11', '01', 'ZA')
    }

    void testShouldFailForStringDOBForUnder18ForNoCountrySet() {
        assert !service.isLegit('2014', '1', '1', null)
        assert !service.isLegit('2014', '01', '1', null)
        assert !service.isLegit('2014', '0001', '1', null)
        assert !service.isLegit('2014', '11', '01', null)
        assert !service.isLegit('14', '11', '01', null)
    }

    void testShouldPassForStringDOBForOver18ForNoCountrySet() {
        assert service.isLegit('1935', '1', '1', null)
    }

    void testShouldPassForStringDOBForOver18ForSouthAfrica() {
        assert service.isLegit('1935', '1', '1', null)
    }

    //isLegit for Integer age
    void testShouldFailForIntegerAgeForEdgeCases() {
        Integer age = null

        assert !service.isLegit(age, null)
        assert !service.isLegit(0, null)
    }

    void testShouldFailForIntegerAgeForUnder18ForNoCountrySet() {
        assert !service.isLegit(5, null)
        assert !service.isLegit(7, null)
    }

    void testShouldFailForIntegerAgeForUnder18InSouthAfrica() {
        assert !service.isLegit(5, 'ZA')
        assert !service.isLegit(17, 'za')
    }

    void testShouldPassForIntegerAgeForOver18ForNoCountrySet() {
        assert service.isLegit(19, null)
        assert service.isLegit(25, null)
        assert service.isLegit(706, null)
    }

    void testShouldPassForIntegerAgeForOver18ForSouthAfrica() {
        assert service.isLegit(19, 'ZA')
        assert service.isLegit(25, 'za')
        assert service.isLegit(706, 'zA')
    }

    //isLegit for Date birth date age 
    void testShouldFailForDateAgeForEdgeCases() {
        Date age = null

        assert !service.isLegit(age, null)
    }

    void testShouldFailForDateAgeForUnder18ForNoCountrySet() {
        assert !service.isLegit(new Date(), null)
    }

    void testShouldFailForDateAgeForUnder18InSouthAfrica() {
        assert !service.isLegit(new Date(), 'ZA')
    }

    void testShouldPassForDateAgeForOver18ForNoCountrySet() {
        assert service.isLegit(new Date(0), null)
    }

    void testShouldPassForDateAgeForOver18ForSouthAfrica() {
        assert service.isLegit(new Date(0), 'ZA')
    }
}
