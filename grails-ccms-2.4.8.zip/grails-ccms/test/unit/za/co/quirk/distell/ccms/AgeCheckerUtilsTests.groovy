package za.co.quirk.distell.ccms

import za.co.quirk.distell.ccms.util.AgeCheckerUtils

class AgeCheckerUtilsTests {

    //convert4DigitYear
    void testConvertTo4DigitYearForEdgeCases() {
        assert AgeCheckerUtils.convert4DigitYear(null) == null
        assert AgeCheckerUtils.convert4DigitYear('') == ''
    }

    void testConvertTo4DigitYearForNoConversionRequired() {
        assert AgeCheckerUtils.convert4DigitYear('2014') == '2014'
        assert AgeCheckerUtils.convert4DigitYear('1950') == '1950'
        assert AgeCheckerUtils.convert4DigitYear('1255') == '1255'
        assert AgeCheckerUtils.convert4DigitYear('2100') == '2100'
    }

    void testConvertTo4DigitYearForConversionRequired() {
        assert AgeCheckerUtils.convert4DigitYear('14') == '2014'
        assert AgeCheckerUtils.convert4DigitYear('50') == '1950'
        assert AgeCheckerUtils.convert4DigitYear('99') == '1999'
        assert AgeCheckerUtils.convert4DigitYear('01') == '2001'
        assert AgeCheckerUtils.convert4DigitYear('1') == '2001'
    }
}
