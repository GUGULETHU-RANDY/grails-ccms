package za.co.quirk.distell.ccms

import za.co.quirk.distel.ccms.Utilities

class UtilitiesTests {

    //appendParams
    void testAppendParamsForEdgeCases() {
        assert Utilities.appendParams(null, null, null) == ''
        assert Utilities.appendParams('', '', '') == ''
        assert Utilities.appendParams('', null, '') == ''
        assert Utilities.appendParams(null, '', '') == ''
        assert Utilities.appendParams('', '', null) == ''
    }

    void testAppendParamsShouldNotAppendIfKeyOrValueNotPresent() {
        assert Utilities.appendParams('test', null, null) == 'test'
        assert Utilities.appendParams('test', 'key', null) == 'test'
        assert Utilities.appendParams('test', null, 'value') == 'test'
    }

    void testAppendParamsShouldAppendWithQuestionMarkIfKeyAndValuePresentAndNoExistingParams() {
        assert Utilities.appendParams('test', 'key', 'value') == 'test?key=value'
    }

    void testAppendParamsShouldAppendWithQuestionMarkIfKeyAndValuePresentAndExistingParams() {
        assert Utilities.appendParams('test?key1=value1', 'key2', 'value2') == 'test?key1=value1&key2=value2'
        assert Utilities.appendParams('test?key1=value1', 'key2', 'value2,value3') == 'test?key1=value1&key2=value2,value3'
    }

    //parseResponse
    void testParseResponseForEdgeCases() {
        assert Utilities.parseResponse(null) == [:]
        assert Utilities.parseResponse('') == [:]
        assert Utilities.parseResponse('test') == [:]
    }

    void testParseResponseForNormalQueryString() {
        assert Utilities.parseResponse('test=1') == [test:'1']
        assert Utilities.parseResponse('test=1&test2=2') == [test:'1', test2: '2']
    }
}
