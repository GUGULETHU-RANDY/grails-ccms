import za.co.quirk.distell.ccms.bean.DistellCCMSConsumer
import za.co.quirk.distell.ccms.service.CCMSConsumerService

class BrandCloudTests extends GroovyTestCase {

    void testInsertUpdate() {
        DistellCCMSConsumer toInsertConsumer = new DistellCCMSConsumer()

        String signature = Math.random().toString()

        toInsertConsumer.setEmailAddress('test@quirk.biz')
        toInsertConsumer.setFirstName('Test' + signature)
        toInsertConsumer.setLastName('Quirk' + signature)
        toInsertConsumer.setContactNumber("0799999999")
        toInsertConsumer.setSource('test')
        toInsertConsumer.setEmailOptin(false)
        toInsertConsumer.setSmsOptin(false)
        toInsertConsumer.setPassword("password")

        CCMSConsumerService service = new CCMSConsumerService('Mainstay', '57eb3f38-1435-11e1-a1e5-000c2935cefa', false)

        String insertResponse = service.send(toInsertConsumer)

        assertEquals("success", insertResponse)
        println("Insert Successful")

        Thread.sleep(1000);

        DistellCCMSConsumer insertedConsumer = service.getConsumerDetails("test@quirk.biz")

        assertEquals("test@quirk.biz", insertedConsumer.emailAddress)
        assertEquals('Test' + signature, insertedConsumer.firstName)
        assertEquals('Quirk' + signature, insertedConsumer.lastName)
        assertEquals("+27799999999", insertedConsumer.contactNumber)
    }

    void testLogin() {
        CCMSConsumerService service = new CCMSConsumerService('Mainstay', '57eb3f38-1435-11e1-a1e5-000c2935cefa', false)
        String ccmsSession = service.loginConsumer("spider@quirk.biz", "password")

        assertNotNull(ccmsSession)
    }
}